## Como gerar o plugin `.vst3` no Windows (2 caminhos fáceis)

### Caminho 1 — Grátis na nuvem via GitHub Actions (sem instalar nada)
1. Crie um repositório (pode ser privado) no GitHub e envie todos os arquivos desta pasta (incluindo `.github/workflows/build-windows.yml`).
2. Abra a aba **Actions** no repositório, clique em **Build PulseTrigger 2 (Windows VST3 & Standalone)** e depois em **Run workflow**.
3. Em ~5 minutos, baixe o pacote **PulseTrigger2-Windows-VST3-Standalone** no final da página e copie `PulseTrigger 2.vst3` para `C:\Program Files\Common Files\VST3`.

### Caminho 2 — 2 cliques no seu Windows (`compilar_windows.bat`)
1. Instale **Visual Studio 2022 Community** (marcando *Desenvolvimento para desktop com C++*), **CMake** (no PATH) e **Git**.
2. Dê duplo clique em **`compilar_windows.bat`**. Ele compila o `.vst3` e o `.exe`, roda os testes DSP e abre a pasta pronta automaticamente.

---

# PulseTrigger 2 — Ultra-Low Latency Drum Replacement Plugin (C++20 / JUCE 8)

Plugin de substituição e reforço de bateria em tempo real inspirado na ergonomia do Slate Digital Trigger 2 Platinum, projetado para **latência no limite físico (0 / 0,36 / 2,17 ms)** e **baixo uso de CPU (O(1) sem FFT)** em máquinas modestas.

## Recursos implementados

- **Motor de detecção em 5 estágios O(1)** (`Source/DSP/TransientDetector.h`):
  - Filtros sidechain ZDF-SVF (`Low-Cut` / `High-Cut`) sem defasar o áudio seco.
  - Supressão adaptativa de vazamento (`Suppress` + `Bleed Gain`) compatível com modo clássico **Estéreo L/R** e **Sidechain dedicado**.
  - Função de onset multi-pista (razão logarítmica de envelope rápido/lento + derivada positiva + HFC) com histerese e janela cega (`ReTrigger`).
  - 3 modos de latência com atualização dinâmica de PDC (`setLatencySamples`): **Zero (0 ms / 0 smp)**, **Micro (0,36 ms / 16 smp)** e **Phase-Lock (2,17 ms / 96 smp)**.
- **Gate acionado por transientes** (`Source/DSP/TransientGate.h`) aplicado exclusivamente ao áudio seco (`Attack` / `Hold` / `Release`).
- **Motor polifônico de 8 slots estéreo** (`Source/DSP/SampleEngine.h`):
  - **Offline Transient Trimming**: corta automaticamente silêncio pré-transiente ao carregar na RAM (0% de CPU extra).
  - **Fast-path sem resampling** quando `Tune = 0`.
  - **Round-Robin anti-repetição** + envelope ASR por slot + inversão de fase individual e global (`Flip Phases`).
- **Editor Visual de Velocity** (`Source/UI/VelocityZoneEditor.h`):
  - Gráfico interativo de curva `1–127` com ponto laranja ao vivo.
  - Régua `1–127` com agulha laranja em tempo real e faixas **HARD (91–127)**, **MEDIUM (46–90)** e **SOFT / GHOST (1–45)** com *drag-and-drop* de `.wav`/`.aiff`/`.flac`/`.sfz`.
  - Botão **`AUTO-SPLIT BY LOUDNESS`** (ordena e divide samples avulsos automaticamente por RMS) + `Crossfade` suave.
- **MIDI In/Out e MIDI Capture** (`Source/DSP/MidiCaptureEngine.h`): exportação binária de arquivo `.mid` (SMF Type 0) por arrastar-e-soltar (`DRAG TO TRACK`).

## Como compilar (Windows, macOS e Linux)

### Pré-requisitos
- **CMake 3.22+** e compilador **C++20** (Visual Studio 2022 no Windows, Xcode 14+ no macOS ou GCC 12+/Clang no Linux).
- Internet ativa para o `FetchContent` baixar o JUCE 8.0.4 automaticamente (ou passe `-DJUCE_DIR=/caminho/para/JUCE`).

### Build padrão (VST3, AU no macOS e Standalone)
```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --parallel
```

### Incluindo AAX (Pro Tools) e VST2 legado (opcional)
```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release \
  -DAVID_AAX_SDK_PATH=/caminho/para/AAX_SDK \
  -DVST2_SDK_PATH=/caminho/para/VST2_SDK
cmake --build build --config Release --parallel
```

### Rodar os testes unitários do motor DSP (sem precisar do JUCE)
```bash
g++ -std=c++20 -O2 -Wall -Wextra -ISource tests/dsp_verify.cpp -o dsp_verify && ./dsp_verify
```
