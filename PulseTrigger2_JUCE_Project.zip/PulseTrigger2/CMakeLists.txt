cmake_minimum_required(VERSION 3.22)
project(PulseTrigger2 VERSION 1.0.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Option 1: Point to a local JUCE checkout (-DJUCE_DIR=/path/to/JUCE)
# Option 2: Auto-fetch JUCE 8.0.4 via CMake FetchContent (requires internet on build machine)
if(DEFINED JUCE_DIR AND EXISTS "${JUCE_DIR}/CMakeLists.txt")
    add_subdirectory("${JUCE_DIR}" JUCE)
else()
    include(FetchContent)
    FetchContent_Declare(
        JUCE
        GIT_REPOSITORY https://github.com/juce-framework/JUCE.git
        GIT_TAG        8.0.4
    )
    FetchContent_MakeAvailable(JUCE)
endif()

# Configure plugin formats (VST3, AU on macOS, Standalone; optional AAX / VST2 when SDKs are supplied)
set(PT2_FORMATS VST3 Standalone)
if(APPLE)
    list(APPEND PT2_FORMATS AU)
endif()
if(DEFINED AVID_AAX_SDK_PATH AND EXISTS "${AVID_AAX_SDK_PATH}")
    juce_set_aax_sdk_path("${AVID_AAX_SDK_PATH}")
    list(APPEND PT2_FORMATS AAX)
endif()
if(DEFINED VST2_SDK_PATH AND EXISTS "${VST2_SDK_PATH}")
    juce_set_vst2_sdk_path("${VST2_SDK_PATH}")
    list(APPEND PT2_FORMATS VST)
endif()

juce_add_plugin(PulseTrigger2
    COMPANY_NAME                "PulseAudio"
    PLUGIN_MANUFACTURER_CODE    Puls
    PLUGIN_CODE                 Ptr2
    FORMATS                     ${PT2_FORMATS}
    PRODUCT_NAME                "PulseTrigger 2"
    IS_SYNTH                    FALSE
    NEEDS_MIDI_INPUT            TRUE
    NEEDS_MIDI_OUTPUT           TRUE
    IS_MIDI_EFFECT              FALSE
    EDITOR_WANTS_KEYBOARD_FOCUS FALSE
    COPY_PLUGIN_AFTER_BUILD     TRUE
    VST3_CATEGORIES             "Fx" "Dynamics"
    AAX_CATEGORY                AAX_ePlugInCategory_Dynamics
)

target_sources(PulseTrigger2 PRIVATE
    Source/PluginProcessor.cpp
    Source/PluginEditor.cpp
)

target_include_directories(PulseTrigger2 PRIVATE Source)

target_compile_definitions(PulseTrigger2 PUBLIC
    JUCE_WEB_BROWSER=0
    JUCE_USE_CURL=0
    JUCE_VST3_CAN_REPLACE_VST2=0
    JUCE_MODAL_LOOPS_PERMITTED=1
)

target_link_libraries(PulseTrigger2
    PRIVATE
        juce::juce_audio_utils
        juce::juce_audio_formats
        juce::juce_dsp
    PUBLIC
        juce::juce_recommended_config_flags
        juce::juce_recommended_lto_flags
        juce::juce_recommended_warning_flags
)

# Standalone pure-C++20 DSP unit test (no JUCE required)
add_executable(dsp_verify tests/dsp_verify.cpp)
target_include_directories(dsp_verify PRIVATE Source)
