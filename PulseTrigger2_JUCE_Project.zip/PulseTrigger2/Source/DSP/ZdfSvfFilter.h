#pragma once
#include <cmath>
#include <algorithm>

namespace pt2 {

// Zero-Delay Feedback 2nd-Order State Variable Filter (TPT / Cytomic style).
// Runs in O(1) per sample with zero phase distortion on the dry audio path
// (used exclusively on the sidechain detection circuit for Low-Cut / High-Cut).
class ZdfSvfFilter {
public:
    enum class Mode { LowPass, HighPass, BandPass };

    void prepare(double sampleRate) noexcept {
        sr_ = std::max(8000.0, sampleRate);
        reset();
        updateCoefficients();
    }

    void reset() noexcept {
        ic1eq_ = 0.0f;
        ic2eq_ = 0.0f;
    }

    void setCutoffHz(float hz) noexcept {
        const float clamped = std::clamp(hz, 10.0f, static_cast<float>(sr_ * 0.45));
        if (std::abs(clamped - cutoffHz_) > 0.01f) {
            cutoffHz_ = clamped;
            updateCoefficients();
        }
    }

    void setQ(float q) noexcept {
        const float clamped = std::clamp(q, 0.5f, 4.0f);
        if (std::abs(clamped - q_) > 0.001f) {
            q_ = clamped;
            updateCoefficients();
        }
    }

    void setMode(Mode m) noexcept { mode_ = m; }

    inline float processSample(float v0) noexcept {
        const float v3 = v0 - ic2eq_;
        const float v1 = a1_ * ic1eq_ + a2_ * v3;
        const float v2 = ic2eq_ + a2_ * ic1eq_ + a3_ * v3;
        ic1eq_ = 2.0f * v1 - ic1eq_;
        ic2eq_ = 2.0f * v2 - ic2eq_;

        switch (mode_) {
            case Mode::LowPass:  return v2;
            case Mode::BandPass: return v1;
            case Mode::HighPass: return v0 - k_ * v1 - v2;
        }
        return v0;
    }

private:
    void updateCoefficients() noexcept {
        constexpr double kPi = 3.14159265358979323846;
        const double g = std::tan(kPi * static_cast<double>(cutoffHz_) / sr_);
        const double k = 1.0 / static_cast<double>(q_);
        const double a1 = 1.0 / (1.0 + g * (g + k));
        const double a2 = g * a1;
        const double a3 = g * a2;
        k_  = static_cast<float>(k);
        a1_ = static_cast<float>(a1);
        a2_ = static_cast<float>(a2);
        a3_ = static_cast<float>(a3);
    }

    double sr_ = 44100.0;
    float cutoffHz_ = 1000.0f;
    float q_ = 0.70710678f;
    Mode mode_ = Mode::LowPass;
    float k_ = 1.41421356f, a1_ = 0.0f, a2_ = 0.0f, a3_ = 0.0f;
    float ic1eq_ = 0.0f, ic2eq_ = 0.0f;
};

} // namespace pt2
