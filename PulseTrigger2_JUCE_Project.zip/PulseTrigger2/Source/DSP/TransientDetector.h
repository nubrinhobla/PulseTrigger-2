#pragma once
#include "ZdfSvfFilter.h"
#include <array>
#include <cmath>
#include <cstdint>
#include <algorithm>

namespace pt2 {

enum class LatencyMode : int {
    Zero      = 0, // 0 samples   (0.00 ms @ 44.1 kHz)
    Micro     = 1, // 16 samples  (0.36 ms @ 44.1 kHz)
    PhaseLock = 2  // 96 samples  (2.17 ms @ 44.1 kHz)
};

struct DetectorParams {
    float inputGainDb   = 0.0f;      // -24..+24 dB
    float lowCutHz      = 20.0f;     // 20..2000 Hz (<=22 Hz bypasses)
    float highCutHz     = 20000.0f;  // 200..20000 Hz (>=19900 Hz bypasses)
    float suppressPct   = 0.0f;      // 0..100 %
    float bleedGainDb   = 0.0f;      // -24..+24 dB
    float detail        = 25.0f;     // 0..100 (threshold floor)
    float sensitivity   = 60.0f;     // 0..100 (ghost note vs bleed ratio)
    float retriggerMs   = 30.0f;     // 5..150 ms blind window
    LatencyMode latency = LatencyMode::Micro;
    bool useStereoLRBleed = false;   // Classic Trigger 2 mode: L=Source, R=Bleed
    bool keyListen = false;          // Solo filtered sidechain signal (FabFilter/Sonnox style)
};

struct TriggerEvent {
    bool fired = false;
    bool preOpenGate = false;        // Fires immediately at onset (before lookahead delay) so Gate never chops attack
    float velocity01 = 0.0f;         // 0..1 calibrated studio drum velocity
    int midiVelocity = 0;            // 1..127
    float polarity = 1.0f;
    float filteredSidechain = 0.0f;  // for Key Listen auditioning
    float suppressedLevel = 0.0f;    // for red oscilloscope bleed overlay
    bool inRetriggerBlind = false;
};

// 5-Stage O(1) Multi-Cue Time-Domain Transient Detector (Zero FFT).
// Uses studio dB-to-Velocity calibration (-42 dBFS -> Vel 1, -3 dBFS -> Vel 127)
// so real drum tracks recorded at -18 to -6 dBFS trigger loud, punchy, and dynamic out of the box.
class TransientDetector {
public:
    static constexpr int kMaxLookahead = 256;

    void prepare(double sampleRate) noexcept {
        sr_ = std::max(8000.0, sampleRate);
        hpf_.prepare(sr_);
        hpf_.setMode(ZdfSvfFilter::Mode::HighPass);
        lpf_.prepare(sr_);
        lpf_.setMode(ZdfSvfFilter::Mode::LowPass);
        bleedHpf_.prepare(sr_);
        bleedHpf_.setMode(ZdfSvfFilter::Mode::HighPass);
        bleedLpf_.prepare(sr_);
        bleedLpf_.setMode(ZdfSvfFilter::Mode::LowPass);

        fastAtk_  = coeffFromMs(0.20);
        fastRel_  = coeffFromMs(8.0);
        slowAtk_  = coeffFromMs(24.0);
        slowRel_  = coeffFromMs(80.0);
        bleedAtk_ = coeffFromMs(0.30);
        bleedRel_ = coeffFromMs(15.0);
        reset();
    }

    void reset() noexcept {
        hpf_.reset(); lpf_.reset();
        bleedHpf_.reset(); bleedLpf_.reset();
        fastEnv_ = 0.0f;
        slowEnv_ = 1e-5f;
        bleedEnv_ = 0.0f;
        prevFiltered_ = 0.0f;
        retriggerCountdown_ = 0;
        pendingLookahead_ = -1;
        pendingPeak_ = 0.0f;
        pendingPolarity_ = 1.0f;
        armed_ = true;
        delayWriteIdx_ = 0;
        dryDelayL_.fill(0.0f);
        dryDelayR_.fill(0.0f);
    }

    int getLatencySamples(LatencyMode mode) const noexcept {
        const double scale = sr_ / 44100.0;
        switch (mode) {
            case LatencyMode::Zero:      return 0;
            case LatencyMode::Micro:     return std::min(kMaxLookahead - 1, static_cast<int>(std::lround(16.0 * scale)));
            case LatencyMode::PhaseLock: return std::min(kMaxLookahead - 1, static_cast<int>(std::lround(96.0 * scale)));
        }
        return 0;
    }

    static float detailToThreshold(float detail0to100) noexcept {
        const float d = std::clamp(detail0to100 * 0.01f, 0.0f, 1.0f);
        return 0.002f + 0.60f * (d * d * d);
    }

    // Calibrated studio dB-to-Velocity mapping: -42 dBFS -> 0.01, -3 dBFS -> 1.0
    static float peakToStudioVelocity01(float linPeak) noexcept {
        const float db = 20.0f * std::log10(std::max(linPeak, 1e-5f));
        return std::clamp((db + 42.0f) / 39.0f, 0.02f, 1.0f);
    }

    TriggerEvent processSample(float inL, float inR, float sidechainBleed,
                               const DetectorParams& p,
                               float& outDelayedDryL, float& outDelayedDryR) noexcept {
        TriggerEvent ev{};

        const int lat = getLatencySamples(p.latency);
        dryDelayL_[delayWriteIdx_] = inL;
        dryDelayR_[delayWriteIdx_] = inR;
        const int readIdx = (delayWriteIdx_ - lat + kMaxLookahead) % kMaxLookahead;
        outDelayedDryL = dryDelayL_[readIdx];
        outDelayedDryR = dryDelayR_[readIdx];
        delayWriteIdx_ = (delayWriteIdx_ + 1) % kMaxLookahead;

        const float inGain = dbToLin(p.inputGainDb);
        const float sourceRaw = (p.useStereoLRBleed ? inL : 0.5f * (inL + inR)) * inGain;
        const float bleedRaw  = (p.useStereoLRBleed ? inR : sidechainBleed) * dbToLin(p.bleedGainDb);

        float x = sourceRaw;
        if (p.lowCutHz > 22.0f) {
            hpf_.setCutoffHz(p.lowCutHz);
            x = hpf_.processSample(x);
        }
        if (p.highCutHz < 19900.0f) {
            lpf_.setCutoffHz(p.highCutHz);
            x = lpf_.processSample(x);
        }
        ev.filteredSidechain = x;

        float b = bleedRaw;
        if (p.suppressPct > 0.1f) {
            if (p.lowCutHz > 22.0f) {
                bleedHpf_.setCutoffHz(p.lowCutHz);
                b = bleedHpf_.processSample(b);
            }
            if (p.highCutHz < 19900.0f) {
                bleedLpf_.setCutoffHz(p.highCutHz);
                b = bleedLpf_.processSample(b);
            }
        }

        const float absX = std::abs(x);
        const float absB = std::abs(b);

        fastEnv_  = (absX > fastEnv_)  ? (fastAtk_  * fastEnv_  + (1.0f - fastAtk_)  * absX)
                                       : (fastRel_  * fastEnv_  + (1.0f - fastRel_)  * absX);
        slowEnv_  = (absX > slowEnv_)  ? (slowAtk_  * slowEnv_  + (1.0f - slowAtk_)  * absX)
                                       : (slowRel_  * slowEnv_  + (1.0f - slowRel_)  * absX);
        bleedEnv_ = (absB > bleedEnv_) ? (bleedAtk_ * bleedEnv_ + (1.0f - bleedAtk_) * absB)
                                       : (bleedRel_ * bleedEnv_ + (1.0f - bleedRel_) * absB);

        const float suppressAmt = std::clamp(p.suppressPct * 0.01f, 0.0f, 1.0f);
        const float scaledBleed = std::max(absB, bleedEnv_) * (suppressAmt * 2.2f);
        ev.suppressedLevel = scaledBleed;
        const bool suppressedByBleed = (suppressAmt > 0.001f) && (scaledBleed > std::max(absX, fastEnv_) * 0.85f);

        const float diff = x - prevFiltered_;
        const float posDeriv = std::max(0.0f, absX - std::abs(prevFiltered_));
        const float hfc = std::abs(diff);
        prevFiltered_ = x;

        const float logRatio = std::log((std::max(absX, fastEnv_) + 1e-5f) / (slowEnv_ + 1e-5f));
        const float onsetScore = 0.65f * std::max(0.0f, logRatio) + 0.25f * posDeriv * 3.5f + 0.10f * hfc * 1.8f;

        const float thresholdFloor = detailToThreshold(p.detail);
        const float sensNorm = std::clamp(p.sensitivity * 0.01f, 0.0f, 1.0f);
        const float requiredScore = 0.90f - 0.82f * sensNorm;

        if (retriggerCountdown_ > 0) {
            --retriggerCountdown_;
            ev.inRetriggerBlind = true;
        }

        if (!armed_ && (fastEnv_ < thresholdFloor * 0.70f || fastEnv_ < slowEnv_ * 1.12f)) {
            armed_ = true;
        }

        if (pendingLookahead_ >= 0) {
            if (absX > pendingPeak_) {
                pendingPeak_ = absX;
                pendingPolarity_ = (x >= 0.0f) ? 1.0f : -1.0f;
            }
            if (pendingLookahead_ == 0) {
                ev.fired = true;
                ev.velocity01 = peakToStudioVelocity01(pendingPeak_);
                ev.midiVelocity = std::clamp(static_cast<int>(std::lround(ev.velocity01 * 126.0f)) + 1, 1, 127);
                ev.polarity = pendingPolarity_;
                pendingLookahead_ = -1;
            } else {
                --pendingLookahead_;
            }
            return ev;
        }

        if (armed_ && retriggerCountdown_ == 0 && !suppressedByBleed
            && absX >= thresholdFloor && onsetScore >= requiredScore) {
            armed_ = false;
            ev.preOpenGate = true; // Opens Gate immediately (with lookahead!) before dry transient arrives
            retriggerCountdown_ = std::max(1, static_cast<int>(std::lround((p.retriggerMs * 0.001) * sr_)));

            if (lat == 0) {
                const float estVel = peakToStudioVelocity01(absX * 1.25f + posDeriv * 0.5f);
                ev.fired = true;
                ev.velocity01 = estVel;
                ev.midiVelocity = std::clamp(static_cast<int>(std::lround(estVel * 126.0f)) + 1, 1, 127);
                ev.polarity = (x >= 0.0f) ? 1.0f : -1.0f;
            } else {
                pendingLookahead_ = lat;
                pendingPeak_ = absX;
                pendingPolarity_ = (x >= 0.0f) ? 1.0f : -1.0f;
            }
        }

        return ev;
    }

private:
    float coeffFromMs(double ms) const noexcept {
        return static_cast<float>(std::exp(-1.0 / std::max(1.0, (ms * 0.001) * sr_)));
    }
    static float dbToLin(float db) noexcept {
        return std::pow(10.0f, db * 0.05f);
    }

    double sr_ = 44100.0;
    ZdfSvfFilter hpf_, lpf_, bleedHpf_, bleedLpf_;
    float fastAtk_ = 0.0f, fastRel_ = 0.0f;
    float slowAtk_ = 0.0f, slowRel_ = 0.0f;
    float bleedAtk_ = 0.0f, bleedRel_ = 0.0f;
    float fastEnv_ = 0.0f, slowEnv_ = 1e-5f, bleedEnv_ = 0.0f;
    float prevFiltered_ = 0.0f;

    int retriggerCountdown_ = 0;
    int pendingLookahead_ = -1;
    float pendingPeak_ = 0.0f;
    float pendingPolarity_ = 1.0f;
    bool armed_ = true;

    int delayWriteIdx_ = 0;
    std::array<float, kMaxLookahead> dryDelayL_{};
    std::array<float, kMaxLookahead> dryDelayR_{};
};

} // namespace pt2
