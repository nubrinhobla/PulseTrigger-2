#pragma once
#include <array>
#include <atomic>
#include <cstdint>
#include <vector>
#include <algorithm>
#include <cmath>

namespace pt2 {

struct CapturedMidiHit {
    int64_t samplePosition = 0;
    uint8_t channel = 1;  // 1..16
    uint8_t note = 36;    // 0..127 (default C1 Kick)
    uint8_t velocity = 100;
};

// Lock-free MIDI Capture ring buffer + Standard MIDI File (SMF Type 0) binary exporter
// for Trigger 2 style "CLEAR BUFFER" + "DRAG ON TRACK" workflow.
class MidiCaptureEngine {
public:
    static constexpr size_t kMaxHits = 16384;

    void clear() noexcept {
        writeCount_.store(0, std::memory_order_release);
    }

    void recordHit(int64_t samplePos, uint8_t channel, uint8_t note, uint8_t velocity) noexcept {
        const size_t idx = writeCount_.load(std::memory_order_relaxed);
        if (idx >= kMaxHits) return;
        hits_[idx] = { samplePos, channel, note, velocity };
        writeCount_.store(idx + 1, std::memory_order_release);
    }

    size_t getHitCount() const noexcept {
        return std::min(writeCount_.load(std::memory_order_acquire), kMaxHits);
    }

    // Exports captured hits into a valid Standard MIDI File (SMF Type 0, .mid) byte vector.
    std::vector<uint8_t> exportStandardMidiFile(double sampleRate, double bpm = 120.0, uint16_t ppq = 960) const {
        const size_t count = getHitCount();
        std::vector<CapturedMidiHit> sorted(hits_.begin(), hits_.begin() + static_cast<std::ptrdiff_t>(count));
        std::sort(sorted.begin(), sorted.end(), [](const auto& a, const auto& b) {
            return a.samplePosition < b.samplePosition;
        });

        struct RawEvent {
            uint64_t tick;
            uint8_t status, d1, d2;
        };
        std::vector<RawEvent> evs;
        evs.reserve(count * 2);

        const double ticksPerSample = (bpm / 60.0) * static_cast<double>(ppq) / std::max(8000.0, sampleRate);
        const int64_t basePos = sorted.empty() ? 0 : std::min<int64_t>(0, sorted.front().samplePosition);
        const uint64_t noteLenTicks = std::max<uint64_t>(1, ppq / 8);

        for (const auto& h : sorted) {
            const uint64_t tOn = static_cast<uint64_t>(std::max<double>(0.0, static_cast<double>(h.samplePosition - basePos) * ticksPerSample));
            const uint8_t ch = static_cast<uint8_t>(std::clamp<int>(h.channel - 1, 0, 15));
            evs.push_back({ tOn, static_cast<uint8_t>(0x90 | ch), h.note, h.velocity });
            evs.push_back({ tOn + noteLenTicks, static_cast<uint8_t>(0x80 | ch), h.note, 0 });
        }
        std::sort(evs.begin(), evs.end(), [](const auto& a, const auto& b) { return a.tick < b.tick; });

        std::vector<uint8_t> track;
        // Tempo meta-event
        const uint32_t usPerQuarter = static_cast<uint32_t>(std::lround(60000000.0 / std::max(20.0, bpm)));
        writeVarLen(track, 0);
        track.insert(track.end(), { 0xFF, 0x51, 0x03,
            static_cast<uint8_t>((usPerQuarter >> 16) & 0xFF),
            static_cast<uint8_t>((usPerQuarter >> 8) & 0xFF),
            static_cast<uint8_t>(usPerQuarter & 0xFF) });

        uint64_t lastTick = 0;
        for (const auto& e : evs) {
            writeVarLen(track, e.tick - lastTick);
            lastTick = e.tick;
            track.push_back(e.status);
            track.push_back(e.d1);
            track.push_back(e.d2);
        }
        // End of track
        writeVarLen(track, 0);
        track.insert(track.end(), { 0xFF, 0x2F, 0x00 });

        std::vector<uint8_t> smf;
        // MThd header (Type 0, 1 track, ppq)
        smf.insert(smf.end(), { 'M','T','h','d', 0,0,0,6, 0,0, 0,1,
            static_cast<uint8_t>((ppq >> 8) & 0xFF), static_cast<uint8_t>(ppq & 0xFF) });
        // MTrk header
        const uint32_t trkLen = static_cast<uint32_t>(track.size());
        smf.insert(smf.end(), { 'M','T','r','k',
            static_cast<uint8_t>((trkLen >> 24) & 0xFF),
            static_cast<uint8_t>((trkLen >> 16) & 0xFF),
            static_cast<uint8_t>((trkLen >> 8) & 0xFF),
            static_cast<uint8_t>(trkLen & 0xFF) });
        smf.insert(smf.end(), track.begin(), track.end());
        return smf;
    }

private:
    static void writeVarLen(std::vector<uint8_t>& out, uint64_t val) {
        uint8_t buf[10];
        int n = 0;
        buf[n++] = static_cast<uint8_t>(val & 0x7F);
        while ((val >>= 7) > 0) buf[n++] = static_cast<uint8_t>((val & 0x7F) | 0x80);
        while (n > 0) out.push_back(buf[--n]);
    }

    std::array<CapturedMidiHit, kMaxHits> hits_{};
    std::atomic<size_t> writeCount_{ 0 };
};

} // namespace pt2
