#pragma once
#include <cmath>
#include <algorithm>

namespace pt2 {

// Studio-Grade Transient-Driven Drum Gate modeled on FabFilter Pro-G & Sonnox Oxford Drum Gate:
// - Pre-open synced to detector onset (opens before delayed dry transient arrives -> zero attack chop)
// - Smooth cosine S-curve Attack (0.2..30 ms, default 1.2 ms -> zero clicks)
// - Musical Hold (10..300 ms, default 60 ms -> preserves drum body & quick ghost notes)
// - Exponential dB Release (30..1000 ms, default 200 ms -> natural tail decay)
// - Range / Floor (-80..0 dB, default -18 dB -> reduces bleed naturally without unnatural vacuum)
class TransientGate {
public:
    struct Params {
        bool enabled    = false;
        float attackMs  = 1.2f;    // 0.2..30 ms
        float holdMs    = 60.0f;   // 10..300 ms
        float releaseMs = 200.0f;  // 30..1000 ms
        float rangeDb   = -18.0f;  // -80..0 dB (floor when closed)
    };

    void prepare(double sampleRate) noexcept {
        sr_ = std::max(8000.0, sampleRate);
        reset();
    }

    void reset() noexcept {
        openFrac_ = 0.0f; // 0 = closed (at floor), 1 = fully open (0 dB)
        attackPhase_ = 0.0f;
        holdSamplesLeft_ = 0;
        state_ = State::Closed;
    }

    void triggerOpen(const Params& p) noexcept {
        if (!p.enabled) return;
        holdSamplesLeft_ = std::max(1, static_cast<int>(std::lround((p.holdMs * 0.001) * sr_)));
        if (state_ == State::Closed || state_ == State::Release) {
            attackStartFrac_ = openFrac_;
            attackPhase_ = 0.0f;
            state_ = State::Attack;
        } else if (state_ == State::Hold) {
            // Re-triggered while open: simply refresh hold timer smoothly (zero click)
            state_ = State::Hold;
        }
    }

    inline float processGain(const Params& p) noexcept {
        if (!p.enabled) return 1.0f;

        switch (state_) {
            case State::Closed:
                openFrac_ = 0.0f;
                break;

            case State::Attack: {
                const float atkSamples = std::max(1.0f, static_cast<float>((p.attackMs * 0.001) * sr_));
                attackPhase_ += 1.0f / atkSamples;
                if (attackPhase_ >= 1.0f) {
                    openFrac_ = 1.0f;
                    state_ = State::Hold;
                } else {
                    // Smooth half-cosine S-curve (zero clicks even at 0.5-1.2 ms)
                    const float s = 0.5f - 0.5f * std::cos(3.14159265f * attackPhase_);
                    openFrac_ = attackStartFrac_ + (1.0f - attackStartFrac_) * s;
                }
                break;
            }

            case State::Hold:
                openFrac_ = 1.0f;
                if (--holdSamplesLeft_ <= 0) state_ = State::Release;
                break;

            case State::Release: {
                // Smooth exponential release in dB domain
                const float relSamples = std::max(1.0f, static_cast<float>((p.releaseMs * 0.001) * sr_));
                const float dec = 1.0f / relSamples;
                openFrac_ -= dec;
                if (openFrac_ <= 0.0f) {
                    openFrac_ = 0.0f;
                    state_ = State::Closed;
                }
                break;
            }
        }

        // Convert openFrac_ (0..1) into smooth dB attenuation from rangeDb to 0 dB
        const float clampedRange = std::clamp(p.rangeDb, -80.0f, 0.0f);
        const float currentDb = clampedRange * (1.0f - openFrac_);
        return (currentDb <= -79.5f) ? 0.0f : std::pow(10.0f, currentDb * 0.05f);
    }

    bool isOpen() const noexcept { return openFrac_ > 0.15f; }

private:
    enum class State { Closed, Attack, Hold, Release };
    double sr_ = 44100.0;
    float openFrac_ = 0.0f;
    float attackStartFrac_ = 0.0f;
    float attackPhase_ = 0.0f;
    int holdSamplesLeft_ = 0;
    State state_ = State::Closed;
};

} // namespace pt2
