#pragma once
#include "VelocityMapper.h"
#include <array>
#include <vector>
#include <cmath>
#include <cstdint>
#include <algorithm>
#include <string>

namespace pt2 {

// Pre-decoded, session-rate stereo float32 sample in RAM.
// Offline Transient Trimming computes startOffset so hidden pre-transient silence
// adds 0 ms of latency and 0% real-time CPU overhead.
struct LoadedSample {
    std::string name;
    std::vector<float> left;
    std::vector<float> right;
    int startOffset = 0;   // computed offline via trimLeadingSilence()
    float rmsLoudness = 0.0f;

    int numSamples() const noexcept { return static_cast<int>(left.size()); }

    void analyzeOffline() noexcept {
        const int n = numSamples();
        if (n == 0) return;

        // Find peak to compute relative silence threshold (-54 dB below peak)
        float peak = 0.0f;
        double sumSq = 0.0;
        for (int i = 0; i < n; ++i) {
            const float m = std::max(std::abs(left[i]), std::abs(right[i]));
            if (m > peak) peak = m;
            sumSq += 0.5 * (left[i] * left[i] + right[i] * right[i]);
        }
        rmsLoudness = static_cast<float>(std::sqrt(sumSq / static_cast<double>(n)));

        const float thresh = peak * 0.002f; // ~ -54 dB
        startOffset = 0;
        for (int i = 0; i < n; ++i) {
            if (std::max(std::abs(left[i]), std::abs(right[i])) >= thresh) {
                startOffset = std::max(0, i - 2); // preserve 2 samples of pre-attack ramp
                break;
            }
        }
    }
};

struct SlotParams {
    float volumeDb    = 0.0f;     // -inf .. +12 dB
    float pan         = 0.0f;     // -1 (L) .. +1 (R)
    float tuneSt      = 0.0f;     // -12 .. +12 semitones (0 = zero-resampling fast path!)
    bool solo         = false;
    bool mute         = false;
    bool phaseInvert  = false;
    float attackMs    = 0.0f;     // 0..200 ms
    float sustainMs   = 250.0f;   // 10..2000 ms
    float releaseMs   = 350.0f;   // 10..3000 ms
    VelocityCurveParams velCurve{};
};

// 8-Slot Stereo Polyphonic Sample Engine (zero allocation in processSample).
class SampleEngine {
public:
    static constexpr int kNumSlots = 8;
    static constexpr int kMaxVoicesPerSlot = 8; // 64 total pre-allocated voices

    struct SlotData {
        std::vector<LoadedSample> pool;
        std::vector<VelocityZone> zones = {
            { "SOFT / GHOST", 1,  45,  {} },
            { "MEDIUM",       46, 90,  {} },
            { "HARD",         91, 127, {} }
        };
        int lastRRIndex = -1; // Anti-repeat round-robin memory
    };

    void prepare(double sampleRate) noexcept {
        sr_ = std::max(8000.0, sampleRate);
        stopAllVoices();
    }

    void stopAllVoices() noexcept {
        for (auto& v : voices_) v.active = false;
    }

    SlotData& getSlot(int idx) { return slots_[static_cast<size_t>(std::clamp(idx, 0, kNumSlots - 1))]; }
    const SlotData& getSlot(int idx) const { return slots_[static_cast<size_t>(std::clamp(idx, 0, kNumSlots - 1))]; }

    // Triggers all active slots matching the incoming MIDI velocity (1..127).
    void triggerHit(int inMidiVelocity, const std::array<SlotParams, kNumSlots>& params, bool flipAllPhases) noexcept {
        const bool anySolo = std::any_of(params.begin(), params.end(), [](const SlotParams& sp) { return sp.solo; });

        for (int s = 0; s < kNumSlots; ++s) {
            const auto& sp = params[static_cast<size_t>(s)];
            if (sp.mute || (anySolo && !sp.solo)) continue;

            auto& slot = slots_[static_cast<size_t>(s)];
            if (slot.pool.empty()) continue;

            // Check slot overall velocity range
            if (inMidiVelocity < sp.velCurve.rangeMin || inMidiVelocity > sp.velCurve.rangeMax) continue;

            const int mappedMidi = VelocityMapper::mapMidiVelocity(inMidiVelocity, sp.velCurve.velocityCurve);
            const float mapped01 = (mappedMidi - 1) / 126.0f;
            const float dynGain  = VelocityMapper::computeDynamicGain(mapped01, sp.velCurve.dynamics);

            const auto activations = VelocityMapper::evaluateZones(slot.zones, mappedMidi, sp.velCurve.crossfade);
            for (const auto& act : activations) {
                const auto& z = slot.zones[static_cast<size_t>(act.zoneIndex)];
                if (z.sampleIndices.empty()) continue;

                // Anti-Repeat Round-Robin selection
                int pick = pickAntiRepeat(z.sampleIndices, slot.lastRRIndex);
                slot.lastRRIndex = pick;

                const float phaseSign = (sp.phaseInvert ^ flipAllPhases) ? -1.0f : 1.0f;
                const float slotGain  = dbToLin(sp.volumeDb) * dynGain * act.blendGain * phaseSign;
                spawnVoice(s, pick, slotGain, sp);
            }
        }
    }

    // Renders one stereo sample across all active voices (fast path when Tune == 0).
    inline void processSample(float& outL, float& outR) noexcept {
        float sumL = 0.0f, sumR = 0.0f;

        for (auto& v : voices_) {
            if (!v.active) continue;
            const auto& smp = slots_[static_cast<size_t>(v.slotIdx)].pool[static_cast<size_t>(v.sampleIdx)];
            const int len = smp.numSamples();

            float sL = 0.0f, sR = 0.0f;
            if (v.fastNoResample) {
                const int idx = static_cast<int>(v.readPos);
                if (idx >= len) { v.active = false; continue; }
                sL = smp.left[static_cast<size_t>(idx)];
                sR = smp.right[static_cast<size_t>(idx)];
                v.readPos += 1.0;
            } else {
                const int idx = static_cast<int>(v.readPos);
                if (idx + 1 >= len) { v.active = false; continue; }
                const float frac = static_cast<float>(v.readPos - static_cast<double>(idx));
                sL = smp.left[static_cast<size_t>(idx)]  + frac * (smp.left[static_cast<size_t>(idx + 1)]  - smp.left[static_cast<size_t>(idx)]);
                sR = smp.right[static_cast<size_t>(idx)] + frac * (smp.right[static_cast<size_t>(idx + 1)] - smp.right[static_cast<size_t>(idx)]);
                v.readPos += v.pitchRatio;
            }

            // ASR Envelope
            float env = 1.0f;
            if (v.age < v.attackSamples) {
                env = static_cast<float>(v.age) / static_cast<float>(std::max(1, v.attackSamples));
            } else if (v.age >= v.attackSamples + v.sustainSamples) {
                const int relAge = v.age - (v.attackSamples + v.sustainSamples);
                if (relAge >= v.releaseSamples) {
                    v.active = false;
                    continue;
                }
                env = 1.0f - (static_cast<float>(relAge) / static_cast<float>(std::max(1, v.releaseSamples)));
            }
            ++v.age;

            sumL += sL * env * v.gainL;
            sumR += sR * env * v.gainR;
        }

        outL = sumL;
        outR = sumR;
    }

    int getActiveVoiceCount() const noexcept {
        int c = 0;
        for (const auto& v : voices_) if (v.active) ++c;
        return c;
    }

private:
    struct Voice {
        bool active = false;
        int slotIdx = 0;
        int sampleIdx = 0;
        double readPos = 0.0;
        double pitchRatio = 1.0;
        bool fastNoResample = true;
        float gainL = 1.0f;
        float gainR = 1.0f;
        int age = 0;
        int attackSamples = 0;
        int sustainSamples = 0;
        int releaseSamples = 0;
    };

    int pickAntiRepeat(const std::vector<int>& candidates, int lastIdx) noexcept {
        if (candidates.size() == 1) return candidates[0];
        // Fast xorshift32 PRNG (zero allocation, real-time safe)
        rngState_ ^= rngState_ << 13;
        rngState_ ^= rngState_ >> 17;
        rngState_ ^= rngState_ << 5;
        int pick = candidates[rngState_ % candidates.size()];
        if (pick == lastIdx) {
            pick = candidates[(rngState_ + 1) % candidates.size()];
        }
        return pick;
    }

    void spawnVoice(int slotIdx, int sampleIdx, float totalGain, const SlotParams& sp) noexcept {
        // Find free voice or steal oldest voice in same slot
        Voice* target = nullptr;
        int maxAge = -1;
        for (auto& v : voices_) {
            if (!v.active) { target = &v; break; }
            if (v.slotIdx == slotIdx && v.age > maxAge) {
                maxAge = v.age;
                target = &v;
            }
        }
        if (!target) target = &voices_[0];

        const auto& smp = slots_[static_cast<size_t>(slotIdx)].pool[static_cast<size_t>(sampleIdx)];
        const float panAngle = (std::clamp(sp.pan, -1.0f, 1.0f) + 1.0f) * 0.78539816f; // 0..pi/2

        target->active = true;
        target->slotIdx = slotIdx;
        target->sampleIdx = sampleIdx;
        target->readPos = static_cast<double>(smp.startOffset);
        target->fastNoResample = (std::abs(sp.tuneSt) < 0.005f);
        target->pitchRatio = target->fastNoResample ? 1.0 : std::pow(2.0, static_cast<double>(sp.tuneSt) / 12.0);
        target->gainL = totalGain * std::cos(panAngle) * 1.41421356f;
        target->gainR = totalGain * std::sin(panAngle) * 1.41421356f;
        target->age = 0;
        target->attackSamples  = static_cast<int>(std::lround((sp.attackMs  * 0.001) * sr_));
        target->sustainSamples = static_cast<int>(std::lround((sp.sustainMs * 0.001) * sr_));
        target->releaseSamples = std::max(1, static_cast<int>(std::lround((sp.releaseMs * 0.001) * sr_)));
    }

    static float dbToLin(float db) noexcept {
        return (db <= -60.0f) ? 0.0f : std::pow(10.0f, db * 0.05f);
    }

    double sr_ = 44100.0;
    uint32_t rngState_ = 0x13579BDFu;
    std::array<SlotData, kNumSlots> slots_{};
    std::array<Voice, kNumSlots * kMaxVoicesPerSlot> voices_{};
};

} // namespace pt2
