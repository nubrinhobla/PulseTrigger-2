#pragma once
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>

namespace pt2 {

struct VelocityCurveParams {
    float velocityCurve = 50.0f;  // 0..100 (50 = linear, >50 aggressive, <50 soft)
    float dynamics      = 100.0f; // 0..100 (0 = flat max volume, 100 = full dynamic range)
    float crossfade     = 8.0f;   // 0..32 MIDI velocity units smooth zone blending
    int rangeMin        = 1;      // 1..127
    int rangeMax        = 127;    // 1..127
};

struct VelocityZone {
    std::string label; // "SOFT / GHOST", "MEDIUM", "HARD"
    int minVel = 1;    // 1..127
    int maxVel = 127;  // 1..127
    std::vector<int> sampleIndices; // round-robin pool inside this zone
};

struct ZoneActivation {
    int zoneIndex = -1;
    float blendGain = 0.0f; // 0..1 (supports crossfade between adjacent zones)
};

class VelocityMapper {
public:
    // Maps input velocity (1..127) through the Trigger 2 style curve (50 = linear).
    static float mapVelocity01(float inVel01, float curve0to100) noexcept {
        const float x = std::clamp(inVel01, 0.0f, 1.0f);
        const float c = std::clamp(curve0to100, 0.0f, 100.0f);
        // curve 50 -> gamma 1.0 (linear); >50 -> gamma < 1 (convex/harder); <50 -> gamma > 1 (concave/softer)
        const float norm = (c - 50.0f) / 50.0f; // -1..+1
        const float gamma = std::pow(3.0f, -norm); // 3.0 (soft) .. 1.0 (linear) .. 0.333 (aggressive)
        return std::clamp(std::pow(x, gamma), 0.0f, 1.0f);
    }

    static int mapMidiVelocity(int inMidiVel, float curve0to100) noexcept {
        const float v01 = std::clamp((inMidiVel - 1) / 126.0f, 0.0f, 1.0f);
        const float mapped = mapVelocity01(v01, curve0to100);
        return std::clamp(static_cast<int>(std::lround(mapped * 126.0f)) + 1, 1, 127);
    }

    // Dynamics control (0..100): 100 = full velocity scaling, 0 = constant loud output.
    static float computeDynamicGain(float mappedVel01, float dynamics0to100) noexcept {
        const float d = std::clamp(dynamics0to100 * 0.01f, 0.0f, 1.0f);
        const float minGain = 1.0f - d;
        return minGain + d * std::clamp(mappedVel01, 0.05f, 1.0f);
    }

    // Evaluates which velocity zone(s) activate for a given mapped MIDI velocity,
    // supporting smooth crossfading at zone boundaries.
    static std::vector<ZoneActivation> evaluateZones(const std::vector<VelocityZone>& zones,
                                                     int mappedMidiVel,
                                                     float crossfadeWidth) {
        std::vector<ZoneActivation> out;
        const float v = static_cast<float>(std::clamp(mappedMidiVel, 1, 127));
        const float xf = std::max(0.0f, crossfadeWidth);

        for (int i = 0; i < static_cast<int>(zones.size()); ++i) {
            const auto& z = zones[static_cast<size_t>(i)];
            if (z.sampleIndices.empty()) continue;

            const float lo = static_cast<float>(z.minVel);
            const float hi = static_cast<float>(z.maxVel);

            if (v >= lo && v <= hi) {
                float gain = 1.0f;
                if (xf > 0.5f) {
                    if (v - lo < xf * 0.5f && lo > 1.0f)
                        gain = std::min(gain, 0.5f + (v - lo) / xf);
                    if (hi - v < xf * 0.5f && hi < 127.0f)
                        gain = std::min(gain, 0.5f + (hi - v) / xf);
                }
                out.push_back({ i, std::clamp(gain, 0.0f, 1.0f) });
            } else if (xf > 0.5f) {
                if (v < lo && (lo - v) < xf * 0.5f) {
                    const float g = 0.5f - (lo - v) / xf;
                    if (g > 0.01f) out.push_back({ i, g });
                } else if (v > hi && (v - hi) < xf * 0.5f) {
                    const float g = 0.5f - (v - hi) / xf;
                    if (g > 0.01f) out.push_back({ i, g });
                }
            }
        }
        return out;
    }

    // AUTO-SPLIT BY LOUDNESS: sorts loose samples by measured RMS/peak loudness
    // and automatically populates Soft (1-45), Medium (46-90), Hard (91-127) lanes.
    struct SampleLoudnessEntry {
        int sampleIndex = 0;
        float rmsLoudness = 0.0f;
    };

    static std::vector<VelocityZone> autoSplitByLoudness(std::vector<SampleLoudnessEntry> entries) {
        std::vector<VelocityZone> zones = {
            { "SOFT / GHOST", 1,  45,  {} },
            { "MEDIUM",       46, 90,  {} },
            { "HARD",         91, 127, {} }
        };
        if (entries.empty()) return zones;

        std::sort(entries.begin(), entries.end(), [](const auto& a, const auto& b) {
            return a.rmsLoudness < b.rmsLoudness;
        });

        const size_t n = entries.size();
        if (n == 1) {
            zones[0].minVel = 1; zones[0].maxVel = 127;
            zones[0].sampleIndices.push_back(entries[0].sampleIndex);
            return zones;
        }
        if (n == 2) {
            zones[0].minVel = 1;  zones[0].maxVel = 64;  zones[0].sampleIndices.push_back(entries[0].sampleIndex);
            zones[2].minVel = 65; zones[2].maxVel = 127; zones[2].sampleIndices.push_back(entries[1].sampleIndex);
            return zones;
        }

        // Partition into 3 balanced loudness bands (Soft / Medium / Hard)
        for (size_t i = 0; i < n; ++i) {
            const size_t bucket = std::min<size_t>(2, (i * 3) / n);
            zones[bucket].sampleIndices.push_back(entries[i].sampleIndex);
        }
        return zones;
    }
};

} // namespace pt2
