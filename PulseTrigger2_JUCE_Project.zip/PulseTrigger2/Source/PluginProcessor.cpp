#include "PluginProcessor.h"
#include "PluginEditor.h"

PulseTrigger2AudioProcessor::PulseTrigger2AudioProcessor()
    : AudioProcessor(BusesProperties()
        .withInput("Input", juce::AudioChannelSet::stereo(), true)
        .withInput("Sidechain Bleed", juce::AudioChannelSet::stereo(), false)
        .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "PARAMETERS", createParameterLayout()),
      baseLibraryDir_(juce::File::getSpecialLocation(juce::File::userMusicDirectory)) {
    for (auto& f : slotFlash) f.store(0.0f);
    loadDefaultBuiltInSamples(44100.0);
}

juce::AudioProcessorValueTreeState::ParameterLayout PulseTrigger2AudioProcessor::createParameterLayout() {
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;

    p.push_back(std::make_unique<juce::AudioParameterFloat>("inputGain", "Input Volume", -24.0f, 24.0f, 0.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("lowCut", "Low Cut", juce::NormalisableRange<float>(20.0f, 2000.0f, 1.0f, 0.4f), 20.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("highCut", "High Cut", juce::NormalisableRange<float>(200.0f, 20000.0f, 1.0f, 0.4f), 20000.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("suppress", "Suppress", 0.0f, 100.0f, 0.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("bleedGain", "Bleed Gain", -24.0f, 24.0f, 0.0f));
    p.push_back(std::make_unique<juce::AudioParameterBool>("stereoLRBleed", "Stereo L/R Bleed Mode", false));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("sensitivity", "Sensitivity", 0.0f, 100.0f, 60.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("retrigger", "Retrigger (ms)", 5.0f, 150.0f, 30.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("detail", "Detail", 0.0f, 100.0f, 25.0f));
    p.push_back(std::make_unique<juce::AudioParameterChoice>("latencyMode", "Latency Mode", juce::StringArray{ "Zero (0ms)", "Micro (0.36ms)", "Phase (2.17ms)" }, 1));

    p.push_back(std::make_unique<juce::AudioParameterBool>("gateOn", "Gate On", false));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("gateAttack", "Gate Attack", 0.2f, 30.0f, 1.2f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("gateHold", "Gate Hold", 10.0f, 300.0f, 60.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("gateRelease", "Gate Release", 30.0f, 1000.0f, 200.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("gateRange", "Gate Range (dB)", -80.0f, 0.0f, -18.0f));
    p.push_back(std::make_unique<juce::AudioParameterBool>("keyListen", "Sidechain Key Listen", false));

    p.push_back(std::make_unique<juce::AudioParameterFloat>("outputGain", "Output Volume", -24.0f, 24.0f, 0.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>("mix", "Mix", 0.0f, 100.0f, 100.0f));
    p.push_back(std::make_unique<juce::AudioParameterBool>("flipAllPhases", "Flip All Phases", false));
    p.push_back(std::make_unique<juce::AudioParameterBool>("midiOutOn", "MIDI Out On", true));
    p.push_back(std::make_unique<juce::AudioParameterInt>("midiNote", "MIDI Note", 0, 127, 36)); // C1 Kick default
    p.push_back(std::make_unique<juce::AudioParameterInt>("midiChannel", "MIDI Channel", 1, 16, 1));

    for (int i = 0; i < pt2::SampleEngine::kNumSlots; ++i) {
        const auto id = "slot" + juce::String(i + 1) + "_";
        p.push_back(std::make_unique<juce::AudioParameterFloat>(id + "vol",   "Slot " + juce::String(i + 1) + " Vol",   -60.0f, 12.0f, 0.0f));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(id + "pan",   "Slot " + juce::String(i + 1) + " Pan",   -1.0f, 1.0f, 0.0f));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(id + "tune",  "Slot " + juce::String(i + 1) + " Tune",  -12.0f, 12.0f, 0.0f));
        p.push_back(std::make_unique<juce::AudioParameterBool>( id + "solo",  "Slot " + juce::String(i + 1) + " Solo",  false));
        p.push_back(std::make_unique<juce::AudioParameterBool>( id + "mute",  "Slot " + juce::String(i + 1) + " Mute",  false));
        p.push_back(std::make_unique<juce::AudioParameterBool>( id + "phase", "Slot " + juce::String(i + 1) + " Phase", false));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(id + "velCurve",  "Slot " + juce::String(i + 1) + " Velocity",  0.0f, 100.0f, 50.0f));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(id + "dynamics",  "Slot " + juce::String(i + 1) + " Dynamics",  0.0f, 100.0f, 100.0f));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(id + "crossfade", "Slot " + juce::String(i + 1) + " Crossfade", 0.0f, 32.0f, 8.0f));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(id + "attack",    "Slot " + juce::String(i + 1) + " Attack",    0.0f, 200.0f, 0.0f));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(id + "sustain",   "Slot " + juce::String(i + 1) + " Sustain",   10.0f, 2000.0f, 280.0f));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(id + "release",   "Slot " + juce::String(i + 1) + " Release",   10.0f, 3000.0f, 350.0f));
    }

    return { p.begin(), p.end() };
}

// Synthesizes crisp punchy built-in Kick (Slot 1) and Snare (Slot 2) so the plugin
// works and sounds great IMMEDIATELY on first load even before custom WAVs are dropped.
void PulseTrigger2AudioProcessor::loadDefaultBuiltInSamples(double sampleRate) {
    const juce::SpinLock::ScopedLockType sl(sampleLock_);
    const int len = static_cast<int>(sampleRate * 0.45);
    constexpr double kTwoPi = 6.283185307179586;

    // Slot 0: Punchy Studio Kick (pitch-swept sine + transient click)
    {
        pt2::LoadedSample kick;
        kick.name = "Built-in Kick";
        kick.left.resize(static_cast<size_t>(len));
        kick.right.resize(static_cast<size_t>(len));
        double phase = 0.0;
        for (int n = 0; n < len; ++n) {
            const double t = static_cast<double>(n) / sampleRate;
            const double freq = 48.0 + 135.0 * std::exp(-t * 38.0);
            phase += kTwoPi * freq / sampleRate;
            const double body = std::sin(phase) * std::exp(-t * 9.5);
            const double click = std::sin(kTwoPi * 2400.0 * t) * std::exp(-t * 240.0) * 0.45;
            const float v = static_cast<float>(std::tanh((body + click) * 1.15) * 0.9);
            kick.left[static_cast<size_t>(n)] = v;
            kick.right[static_cast<size_t>(n)] = v;
        }
        kick.analyzeOffline();
        auto& s0 = sampleEngine_.getSlot(0);
        s0.pool.clear();
        s0.pool.push_back(std::move(kick));
        s0.zones = {
            { "SOFT / GHOST", 1,  45,  { 0 } },
            { "MEDIUM",       46, 90,  { 0 } },
            { "HARD",         91, 127, { 0 } }
        };
    }

}

void PulseTrigger2AudioProcessor::prepareToPlay(double sampleRate, int) {
    currentSampleRate_ = sampleRate;
    detector_.prepare(sampleRate);
    gate_.prepare(sampleRate);
    sampleEngine_.prepare(sampleRate);
    if (hasBuiltInDefaults_) loadDefaultBuiltInSamples(sampleRate);
    lastReportedLatency_ = -1;
}

bool PulseTrigger2AudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const {
    const auto mainOut = layouts.getMainOutputChannelSet();
    if (mainOut != juce::AudioChannelSet::stereo() && mainOut != juce::AudioChannelSet::mono()) return false;
    const auto mainIn = layouts.getMainInputChannelSet();
    return (mainIn == juce::AudioChannelSet::mono() || mainIn == juce::AudioChannelSet::stereo());
}

void PulseTrigger2AudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages) {
    juce::ScopedNoDenormals noDenormals;

    pt2::DetectorParams dp;
    dp.inputGainDb      = apvts.getRawParameterValue("inputGain")->load();
    dp.lowCutHz         = apvts.getRawParameterValue("lowCut")->load();
    dp.highCutHz        = apvts.getRawParameterValue("highCut")->load();
    dp.suppressPct      = apvts.getRawParameterValue("suppress")->load();
    dp.bleedGainDb      = apvts.getRawParameterValue("bleedGain")->load();
    dp.useStereoLRBleed = apvts.getRawParameterValue("stereoLRBleed")->load() > 0.5f;
    dp.sensitivity      = apvts.getRawParameterValue("sensitivity")->load();
    dp.retriggerMs      = apvts.getRawParameterValue("retrigger")->load();
    dp.detail           = apvts.getRawParameterValue("detail")->load();
    dp.latency          = static_cast<pt2::LatencyMode>(static_cast<int>(apvts.getRawParameterValue("latencyMode")->load()));

    const int lat = detector_.getLatencySamples(dp.latency);
    if (lat != lastReportedLatency_) {
        setLatencySamples(lat);
        lastReportedLatency_ = lat;
    }

    pt2::TransientGate::Params gp;
    gp.enabled   = apvts.getRawParameterValue("gateOn")->load() > 0.5f;
    gp.attackMs  = apvts.getRawParameterValue("gateAttack")->load();
    gp.holdMs    = apvts.getRawParameterValue("gateHold")->load();
    gp.releaseMs = apvts.getRawParameterValue("gateRelease")->load();
    gp.rangeDb   = apvts.getRawParameterValue("gateRange")->load();
    dp.keyListen = apvts.getRawParameterValue("keyListen")->load() > 0.5f;

    const float outGain = std::pow(10.0f, apvts.getRawParameterValue("outputGain")->load() * 0.05f);
    const float mixWet  = apvts.getRawParameterValue("mix")->load() * 0.01f;
    const float mixDry  = 1.0f - mixWet;
    const bool flipAll  = apvts.getRawParameterValue("flipAllPhases")->load() > 0.5f;
    const bool midiOut  = apvts.getRawParameterValue("midiOutOn")->load() > 0.5f;
    const int midiNote  = static_cast<int>(apvts.getRawParameterValue("midiNote")->load());
    const int midiCh    = static_cast<int>(apvts.getRawParameterValue("midiChannel")->load());

    std::array<pt2::SlotParams, pt2::SampleEngine::kNumSlots> slotParams{};
    for (int i = 0; i < pt2::SampleEngine::kNumSlots; ++i) {
        const auto id = "slot" + juce::String(i + 1) + "_";
        auto& sp = slotParams[static_cast<size_t>(i)];
        sp.volumeDb    = apvts.getRawParameterValue(id + "vol")->load();
        sp.pan         = apvts.getRawParameterValue(id + "pan")->load();
        sp.tuneSt      = apvts.getRawParameterValue(id + "tune")->load();
        sp.solo        = apvts.getRawParameterValue(id + "solo")->load() > 0.5f;
        sp.mute        = apvts.getRawParameterValue(id + "mute")->load() > 0.5f;
        sp.phaseInvert = apvts.getRawParameterValue(id + "phase")->load() > 0.5f;
        sp.velCurve.velocityCurve = apvts.getRawParameterValue(id + "velCurve")->load();
        sp.velCurve.dynamics      = apvts.getRawParameterValue(id + "dynamics")->load();
        sp.velCurve.crossfade     = apvts.getRawParameterValue(id + "crossfade")->load();
        sp.attackMs  = apvts.getRawParameterValue(id + "attack")->load();
        sp.sustainMs = apvts.getRawParameterValue(id + "sustain")->load();
        sp.releaseMs = apvts.getRawParameterValue(id + "release")->load();
    }

    const juce::SpinLock::ScopedTryLockType tryLock(sampleLock_);
    const bool locked = tryLock.isLocked();

    if (locked) {
        for (const auto meta : midiMessages) {
            const auto msg = meta.getMessage();
            if (msg.isNoteOn() && msg.getNoteNumber() == midiNote) {
                sampleEngine_.triggerHit(msg.getVelocity(), slotParams, flipAll);
                lastDetectedMidiVel.store(msg.getVelocity(), std::memory_order_relaxed);
                for (int i = 0; i < pt2::SampleEngine::kNumSlots; ++i)
                    if (!slotParams[static_cast<size_t>(i)].mute && !sampleEngine_.getSlot(i).pool.empty())
                        slotFlash[static_cast<size_t>(i)].store(1.0f, std::memory_order_relaxed);
            }
        }
    }

    auto inBuf  = getBusBuffer(buffer, true, 0);
    auto outBuf = getBusBuffer(buffer, false, 0);
    auto scBuf  = getBusCount(true) > 1 ? getBusBuffer(buffer, true, 1) : juce::AudioBuffer<float>();
    const bool hasSidechain = (scBuf.getNumChannels() > 0 && scBuf.getNumSamples() == inBuf.getNumSamples());

    const int numSamples = inBuf.getNumSamples();
    const bool isStereoIn  = inBuf.getNumChannels() > 1;
    const bool isStereoOut = outBuf.getNumChannels() > 1;
    const float* inPtrL = inBuf.getReadPointer(0);
    const float* inPtrR = isStereoIn ? inBuf.getReadPointer(1) : inPtrL;
    float* outPtrL = outBuf.getWritePointer(0);
    float* outPtrR = isStereoOut ? outBuf.getWritePointer(1) : nullptr;
    const float* scL = hasSidechain ? scBuf.getReadPointer(0) : nullptr;

    float pkInL = 0.0f, pkInR = 0.0f, pkOutL = 0.0f, pkOutR = 0.0f;
    const int decimFactor = std::max(1, static_cast<int>(currentSampleRate_ / 600.0));

    for (int n = 0; n < numSamples; ++n) {
        const float inL = inPtrL[n];
        const float inR = inPtrR[n];
        const float scS = scL ? scL[n] : 0.0f;
        pkInL = std::max(pkInL, std::abs(inL));
        pkInR = std::max(pkInR, std::abs(inR));

        float dryL = 0.0f, dryR = 0.0f;
        const auto ev = detector_.processSample(inL, inR, scS, dp, dryL, dryR);

        if (ev.preOpenGate) {
            gate_.triggerOpen(gp);
        }

        if (ev.fired) {
            if (locked) {
                sampleEngine_.triggerHit(ev.midiVelocity, slotParams, flipAll);
                for (int i = 0; i < pt2::SampleEngine::kNumSlots; ++i)
                    if (!slotParams[static_cast<size_t>(i)].mute && !sampleEngine_.getSlot(i).pool.empty())
                        slotFlash[static_cast<size_t>(i)].store(1.0f, std::memory_order_relaxed);
            }
            lastDetectedMidiVel.store(ev.midiVelocity, std::memory_order_relaxed);
            midiCapture_.recordHit(sampleClock_, static_cast<uint8_t>(midiCh),
                                   static_cast<uint8_t>(midiNote), static_cast<uint8_t>(ev.midiVelocity));
            if (midiOut) {
                midiMessages.addEvent(juce::MidiMessage::noteOn(midiCh, midiNote, static_cast<juce::uint8>(ev.midiVelocity)), n);
            }
        }

        const float gateGain = gate_.processGain(gp);
        float wetL = 0.0f, wetR = 0.0f;
        if (locked) {
            sampleEngine_.processSample(wetL, wetR);
            // Mix Browser 1-click Audition preview if active
            if (previewReadPos_ >= 0 && previewReadPos_ < previewSample_.numSamples()) {
                wetL += previewSample_.left[static_cast<size_t>(previewReadPos_)];
                wetR += previewSample_.right[static_cast<size_t>(previewReadPos_)];
                ++previewReadPos_;
            } else {
                previewReadPos_ = -1;
            }
        }

        const float outL = dp.keyListen ? ev.filteredSidechain : (dryL * gateGain * mixDry + wetL * mixWet) * outGain;
        const float outR = dp.keyListen ? ev.filteredSidechain : (dryR * gateGain * mixDry + wetR * mixWet) * outGain;
        outPtrL[n] = outL;
        if (outPtrR != nullptr) outPtrR[n] = outR;

        pkOutL = std::max(pkOutL, std::abs(outL));
        pkOutR = std::max(pkOutR, std::abs(outR));

        scopeAccum_.wavePeak = std::max(scopeAccum_.wavePeak, std::abs(inL));
        scopeAccum_.bleedPeak = std::max(scopeAccum_.bleedPeak, ev.suppressedLevel);
        scopeAccum_.triggered = scopeAccum_.triggered || ev.fired;
        scopeAccum_.inRetrigger = scopeAccum_.inRetrigger || ev.inRetriggerBlind;
        scopeAccum_.gateOpen = !gp.enabled || gate_.isOpen();

        if (++scopeDecimCounter_ >= decimFactor) {
            const int wp = scopeWritePos.load(std::memory_order_relaxed);
            scopeRing[static_cast<size_t>(wp)] = scopeAccum_;
            scopeWritePos.store((wp + 1) % kScopeSize, std::memory_order_release);
            scopeAccum_ = ScopeFrame{};
            scopeDecimCounter_ = 0;
        }
        ++sampleClock_;
    }

    inputMeterL.store(pkInL, std::memory_order_relaxed);
    inputMeterR.store(pkInR, std::memory_order_relaxed);
    outputMeterL.store(pkOutL, std::memory_order_relaxed);
    outputMeterR.store(pkOutR, std::memory_order_relaxed);
}

bool PulseTrigger2AudioProcessor::loadFilesIntoSlotZone(int slotIdx, int zoneIdx, const juce::StringArray& files) {
    const juce::SpinLock::ScopedLockType sl(sampleLock_);
    sampleEngine_.stopAllVoices();
    auto& slot = sampleEngine_.getSlot(slotIdx);

    // Replace built-in placeholder if user loads their own sample into this slot
    if (!slot.pool.empty() && slot.pool[0].name.rfind("Built-in", 0) == 0) {
        slot.pool.clear();
        for (auto& z : slot.zones) z.sampleIndices.clear();
    }

    bool loadedAny = false;
    for (const auto& fPath : files) {
        juce::File f(fPath);
        if (f.hasFileExtension(".sfz")) {
            if (sampleLoader_.loadSfzKit(f, currentSampleRate_, slot)) {
                slotPrimaryFilePath_[static_cast<size_t>(slotIdx)] = f.getFullPathName();
                hasBuiltInDefaults_ = false;
                loadedAny = true;
            }
            continue;
        }
        pt2::LoadedSample smp;
        if (sampleLoader_.loadSingleAudioFile(f, currentSampleRate_, smp)) {
            const int idx = static_cast<int>(slot.pool.size());
            slot.pool.push_back(std::move(smp));
            if (zoneIdx < 0) {
                // Loaded from Mixer pad: map across all 3 zones (full 1-127 range) so it always triggers!
                for (auto& z : slot.zones) z.sampleIndices.push_back(idx);
            } else {
                const int z = std::clamp(zoneIdx, 0, static_cast<int>(slot.zones.size()) - 1);
                slot.zones[static_cast<size_t>(z)].sampleIndices.push_back(idx);
            }
            slotPrimaryFilePath_[static_cast<size_t>(slotIdx)] = f.getFullPathName();
            hasBuiltInDefaults_ = false;
            loadedAny = true;
        }
    }
    if (loadedAny) {
        if (auto* muteParam = apvts.getParameter("slot" + juce::String(slotIdx + 1) + "_mute"))
            muteParam->setValueNotifyingHost(0.0f);
    }
    return loadedAny;
}

void PulseTrigger2AudioProcessor::clearSlot(int slotIdx) {
    const juce::SpinLock::ScopedLockType sl(sampleLock_);
    sampleEngine_.stopAllVoices();
    auto& slot = sampleEngine_.getSlot(slotIdx);
    slot.pool.clear();
    for (auto& z : slot.zones) z.sampleIndices.clear();
    slotPrimaryFilePath_[static_cast<size_t>(slotIdx)].clear();
}

void PulseTrigger2AudioProcessor::autoSplitSlot(int slotIdx) {
    const juce::SpinLock::ScopedLockType sl(sampleLock_);
    pt2::SampleLoader::autoSplitSlotByLoudness(sampleEngine_.getSlot(slotIdx));
}

void PulseTrigger2AudioProcessor::auditionSlotZone(int slotIdx, int zoneIdx) {
    const juce::SpinLock::ScopedLockType sl(sampleLock_);
    const auto& slot = sampleEngine_.getSlot(slotIdx);
    if (slot.pool.empty()) return;
    const int zClamped = std::clamp(zoneIdx, 0, static_cast<int>(slot.zones.size()) - 1);
    const auto& z = slot.zones[static_cast<size_t>(zClamped)];
    const int midVel = (z.minVel + z.maxVel) / 2;

    std::array<pt2::SlotParams, pt2::SampleEngine::kNumSlots> sp{};
    for (int i = 0; i < pt2::SampleEngine::kNumSlots; ++i) sp[static_cast<size_t>(i)].mute = (i != slotIdx);
    sampleEngine_.triggerHit(midVel, sp, false);
    lastDetectedMidiVel.store(midVel, std::memory_order_relaxed);
    slotFlash[static_cast<size_t>(slotIdx)].store(1.0f, std::memory_order_relaxed);
}

void PulseTrigger2AudioProcessor::auditionPreviewFile(const juce::File& file) {
    pt2::LoadedSample smp;
    if (sampleLoader_.loadSingleAudioFile(file, currentSampleRate_, smp)) {
        const juce::SpinLock::ScopedLockType sl(sampleLock_);
        previewSample_ = std::move(smp);
        previewReadPos_ = previewSample_.startOffset;
    }
}

bool PulseTrigger2AudioProcessor::savePresetToFile(const juce::File& file) {
    auto obj = std::make_unique<juce::DynamicObject>();
    if (auto xml = apvts.copyState().createXml())
        obj->setProperty("parametersXml", xml->toString());

    juce::Array<juce::var> slotFiles;
    for (const auto& p : slotPrimaryFilePath_) slotFiles.add(p);
    obj->setProperty("slotFiles", slotFiles);

    return file.replaceWithText(juce::JSON::toString(juce::var(obj.release())));
}

bool PulseTrigger2AudioProcessor::loadPresetFromFile(const juce::File& file) {
    const auto parsed = juce::JSON::parse(file);
    if (!parsed.isObject()) return false;

    if (const auto xmlStr = parsed.getProperty("parametersXml", "").toString(); xmlStr.isNotEmpty()) {
        if (auto xml = juce::XmlDocument::parse(xmlStr))
            if (xml->hasTagName(apvts.state.getType()))
                apvts.replaceState(juce::ValueTree::fromXml(*xml));
    }

    if (const auto* arr = parsed.getProperty("slotFiles", {}).getArray()) {
        for (int i = 0; i < std::min<int>(arr->size(), pt2::SampleEngine::kNumSlots); ++i) {
            const auto path = (*arr)[i].toString();
            if (path.isNotEmpty() && juce::File(path).existsAsFile()) {
                clearSlot(i);
                loadFilesIntoSlotZone(i, -1, { path });
            }
        }
    }
    return true;
}

juce::String PulseTrigger2AudioProcessor::getSlotDisplayName(int slotIdx) const {
    static const char* kDefaultPadNames[8] = { "1  KICK", "2  SNARE", "3  T1", "4  T2", "5  T3", "6  T4", "7  OH", "8  ROOM" };
    const auto& pool = sampleEngine_.getSlot(slotIdx).pool;
    if (pool.empty()) return kDefaultPadNames[slotIdx % 8];
    return juce::String(slotIdx + 1) + "  " + juce::String(pool.back().name).upToFirstOccurrenceOf(".", false, false);
}

juce::File PulseTrigger2AudioProcessor::exportCapturedMidiTempFile() {
    const auto bytes = midiCapture_.exportStandardMidiFile(currentSampleRate_, 120.0, 960);
    auto tmp = juce::File::getSpecialLocation(juce::File::tempDirectory).getChildFile("PulseTrigger2_Capture.mid");
    tmp.replaceWithData(bytes.data(), bytes.size());
    return tmp;
}

void PulseTrigger2AudioProcessor::getStateInformation(juce::MemoryBlock& destData) {
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary(*xml, destData);
}

void PulseTrigger2AudioProcessor::setStateInformation(const void* data, int sizeInBytes) {
    if (auto xml = getXmlFromBinary(data, sizeInBytes))
        if (xml->hasTagName(apvts.state.getType()))
            apvts.replaceState(juce::ValueTree::fromXml(*xml));
}

juce::AudioProcessorEditor* PulseTrigger2AudioProcessor::createEditor() {
    return new PulseTrigger2AudioProcessorEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() {
    return new PulseTrigger2AudioProcessor();
}
