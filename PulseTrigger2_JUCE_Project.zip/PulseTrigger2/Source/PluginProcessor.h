#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "DSP/TransientDetector.h"
#include "DSP/TransientGate.h"
#include "DSP/SampleEngine.h"
#include "DSP/MidiCaptureEngine.h"
#include "Formats/SampleLoader.h"
#include <atomic>
#include <array>

struct ScopeFrame {
    float wavePeak = 0.0f;
    float bleedPeak = 0.0f;
    bool triggered = false;
    bool inRetrigger = false;
    bool gateOpen = true;
};

class PulseTrigger2AudioProcessor : public juce::AudioProcessor {
public:
    PulseTrigger2AudioProcessor();
    ~PulseTrigger2AudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "PulseTrigger 2"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return true; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 2.5; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "Default"; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    // UI helpers
    juce::AudioProcessorValueTreeState apvts;
    pt2::SampleEngine& getSampleEngine() { return sampleEngine_; }
    pt2::SampleLoader& getSampleLoader() { return sampleLoader_; }
    pt2::MidiCaptureEngine& getMidiCapture() { return midiCapture_; }

    bool loadFilesIntoSlotZone(int slotIdx, int zoneIdx, const juce::StringArray& files);
    void clearSlot(int slotIdx);
    void autoSplitSlot(int slotIdx);
    void auditionSlotZone(int slotIdx, int zoneIdx);
    void auditionPreviewFile(const juce::File& file);
    bool savePresetToFile(const juce::File& file);
    bool loadPresetFromFile(const juce::File& file);
    juce::File exportCapturedMidiTempFile();

    juce::File getBaseLibraryDir() const { return baseLibraryDir_; }
    void setBaseLibraryDir(const juce::File& dir) { baseLibraryDir_ = dir; }
    juce::String getSlotDisplayName(int slotIdx) const;

    // Lock-free telemetry for 60fps UI
    static constexpr int kScopeSize = 512;
    std::array<ScopeFrame, kScopeSize> scopeRing{};
    std::atomic<int> scopeWritePos{ 0 };
    std::atomic<int> lastDetectedMidiVel{ 0 };
    std::atomic<float> inputMeterL{ 0.0f }, inputMeterR{ 0.0f };
    std::atomic<float> outputMeterL{ 0.0f }, outputMeterR{ 0.0f };
    std::array<std::atomic<float>, pt2::SampleEngine::kNumSlots> slotFlash{};

private:
    void loadDefaultBuiltInSamples(double sampleRate);

    pt2::TransientDetector detector_;
    pt2::TransientGate gate_;
    pt2::SampleEngine sampleEngine_;
    pt2::SampleLoader sampleLoader_;
    pt2::MidiCaptureEngine midiCapture_;
    juce::SpinLock sampleLock_;

    // Preview voice for 1-click Browser Audition
    pt2::LoadedSample previewSample_;
    int previewReadPos_ = -1;

    juce::File baseLibraryDir_;
    std::array<juce::String, pt2::SampleEngine::kNumSlots> slotPrimaryFilePath_{};
    bool hasBuiltInDefaults_ = true;

    double currentSampleRate_ = 44100.0;
    int lastReportedLatency_ = -1;
    int64_t sampleClock_ = 0;

    int scopeDecimCounter_ = 0;
    ScopeFrame scopeAccum_{};

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PulseTrigger2AudioProcessor)
};
