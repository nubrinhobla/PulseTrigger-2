#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include "UI/LookAndFeel.h"
#include "UI/OscilloscopeComponent.h"
#include "UI/MixerSlotComponent.h"
#include "UI/VelocityZoneEditor.h"
#include "UI/BrowserPanel.h"
#include "UI/SettingsPanel.h"

class PulseTrigger2AudioProcessorEditor : public juce::AudioProcessorEditor, private juce::Timer {
public:
    explicit PulseTrigger2AudioProcessorEditor(PulseTrigger2AudioProcessor&);
    ~PulseTrigger2AudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    enum class TopTab { Browser, Triggering, Settings };

    void timerCallback() override;
    void setTopTab(TopTab tab);
    void setBottomView(bool showCurves);
    void setLatencyButtons(int modeIdx);
    void savePresetDialog();

    PulseTrigger2AudioProcessor& proc_;
    pt2::PulseLookAndFeel laf_;
    std::unique_ptr<juce::FileChooser> presetChooser_;

    // Left sidebar (100% wired)
    juce::TextButton browserBtn_{ "BROWSER" }, triggeringBtn_{ "TRIGGERING" }, settingsBtn_{ "SETTINGS" };
    juce::TextButton mixerBtn_{ "MIXER" }, curvesBtn_{ "CURVES" };
    juce::TextButton flipPhasesBtn_{ "FLIP PHASES" };
    juce::TextButton savePresetBtn_{ "SAVE PRESET" };
    juce::TextButton midiCaptureBtn_{ "MIDI CAPTURE" };
    juce::TextButton dragMidiBtn_{ "DRAG TO TRACK" };

    // Top tab panels
    TopTab currentTopTab_ = TopTab::Triggering;
    pt2::BrowserPanel browserPanel_;
    pt2::SettingsPanel settingsPanel_;

    // Top-left Gate, Input Meter & Filters (Triggering tab)
    juce::TextButton gateBtn_{ "GATE" };
    pt2::LabeledKnob gateAtk_{ "ATTACK" }, gateHold_{ "HOLD" }, gateRel_{ "RELEASE" }, gateRange_{ "RANGE" };
    juce::TextButton keyListenBtn_{ "KEY" };
    pt2::StereoLedMeter inputMeter_{ "INPUT" };
    pt2::LabeledKnob inputVol_{ "VOLUME" }, lowCut_{ "LOW CUT" }, highCut_{ "HIGH CUT" }, suppress_{ "SUPPRESS" }, bleedGain_{ "BLEED GAIN" };

    // Top-center Oscilloscope (Triggering tab)
    pt2::OscilloscopeComponent scope_;

    // Top-right Latency 3-way pill switch, Detection, Output Meter & Mix (Triggering tab)
    juce::Label latencyTitle_;
    juce::TextButton latZeroBtn_{ "ZERO" }, latMicroBtn_{ "MICRO" }, latPhaseBtn_{ "PHASE" };
    pt2::LabeledKnob sensitivity_{ "SENSITIVITY" }, retrigger_{ "RETRIGGER" }, detail_{ "DETAIL" };
    pt2::StereoLedMeter outputMeter_{ "OUTPUT" };
    pt2::LabeledKnob mix_{ "MIX" };

    // Bottom views: 8-slot Mixer & Visual Velocity Zone Editor
    std::array<std::unique_ptr<pt2::MixerSlotComponent>, pt2::SampleEngine::kNumSlots> slots_;
    pt2::VelocityZoneEditor velocityEditor_;
    bool showingCurves_ = false;
    int selectedSlot_ = 0;

    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAtts_;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAtts_;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PulseTrigger2AudioProcessorEditor)
};
