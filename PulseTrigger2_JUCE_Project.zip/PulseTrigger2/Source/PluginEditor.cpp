#include "PluginEditor.h"

PulseTrigger2AudioProcessorEditor::PulseTrigger2AudioProcessorEditor(PulseTrigger2AudioProcessor& p)
    : AudioProcessorEditor(&p),
      proc_(p),
      browserPanel_(p, [this] { return selectedSlot_; },
                    [this] {
                        for (auto& s : slots_) if (s) s->refreshLabel();
                        velocityEditor_.repaint();
                    }),
      settingsPanel_(p),
      scope_(p),
      velocityEditor_(p) {
    setLookAndFeel(&laf_);

    // Left sidebar: Top tab switches (ALL functional!)
    browserBtn_.setClickingTogglesState(true);
    triggeringBtn_.setClickingTogglesState(true);
    settingsBtn_.setClickingTogglesState(true);
    browserBtn_.onClick    = [this] { setTopTab(TopTab::Browser); };
    triggeringBtn_.onClick = [this] { setTopTab(TopTab::Triggering); };
    settingsBtn_.onClick   = [this] { setTopTab(TopTab::Settings); };
    addAndMakeVisible(browserBtn_);
    addAndMakeVisible(triggeringBtn_);
    addAndMakeVisible(settingsBtn_);

    // Left sidebar: Bottom view switches
    mixerBtn_.setClickingTogglesState(true);
    curvesBtn_.setClickingTogglesState(true);
    mixerBtn_.onClick  = [this] { setBottomView(false); };
    curvesBtn_.onClick = [this] { setBottomView(true); };
    addAndMakeVisible(mixerBtn_);
    addAndMakeVisible(curvesBtn_);

    // Left sidebar: Global utility actions
    flipPhasesBtn_.setClickingTogglesState(true);
    addAndMakeVisible(flipPhasesBtn_);
    buttonAtts_.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(proc_.apvts, "flipAllPhases", flipPhasesBtn_));

    savePresetBtn_.onClick = [this] { savePresetDialog(); };
    addAndMakeVisible(savePresetBtn_);

    midiCaptureBtn_.setTooltip("Click to clear captured MIDI buffer");
    midiCaptureBtn_.onClick = [this] { proc_.getMidiCapture().clear(); };
    addAndMakeVisible(midiCaptureBtn_);

    dragMidiBtn_.setColour(juce::TextButton::buttonColourId, pt2::PulseLookAndFeel::kAmberTrig.darker(0.18f));
    dragMidiBtn_.onClick = [this] {
        auto midFile = proc_.exportCapturedMidiTempFile();
        juce::DragAndDropContainer::performExternalDragDropOfFiles({ midFile.getFullPathName() }, false);
    };
    addAndMakeVisible(dragMidiBtn_);

    // Browser & Settings panels
    addChildComponent(browserPanel_);
    addChildComponent(settingsPanel_);

    // Triggering tab controls
    gateBtn_.setClickingTogglesState(true);
    addAndMakeVisible(gateBtn_);
    buttonAtts_.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(proc_.apvts, "gateOn", gateBtn_));

    auto bindKnob = [this](pt2::LabeledKnob& k, const juce::String& paramId) {
        addAndMakeVisible(k);
        sliderAtts_.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc_.apvts, paramId, k.slider));
    };

    bindKnob(gateAtk_,   "gateAttack");
    bindKnob(gateHold_,  "gateHold");
    bindKnob(gateRel_,   "gateRelease");
    bindKnob(gateRange_, "gateRange");
    keyListenBtn_.setClickingTogglesState(true);
    keyListenBtn_.setTooltip("Solo filtered sidechain signal (Key Listen)");
    addAndMakeVisible(keyListenBtn_);
    buttonAtts_.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(proc_.apvts, "keyListen", keyListenBtn_));
    addAndMakeVisible(inputMeter_);
    bindKnob(inputVol_,  "inputGain");
    bindKnob(lowCut_,    "lowCut");
    bindKnob(highCut_,   "highCut");
    bindKnob(suppress_,  "suppress");
    bindKnob(bleedGain_, "bleedGain");

    addAndMakeVisible(scope_);

    latencyTitle_.setText("LATENCY", juce::dontSendNotification);
    latencyTitle_.setJustificationType(juce::Justification::centred);
    latencyTitle_.setFont(juce::FontOptions(10.5f, juce::Font::bold));
    latencyTitle_.setColour(juce::Label::textColourId, pt2::PulseLookAndFeel::kTextMute);
    addAndMakeVisible(latencyTitle_);

    auto setupLatBtn = [this](juce::TextButton& b, int modeIdx) {
        b.setClickingTogglesState(true);
        b.onClick = [this, modeIdx] {
            if (auto* param = proc_.apvts.getParameter("latencyMode"))
                param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(modeIdx)));
            setLatencyButtons(modeIdx);
            settingsPanel_.refreshStatus();
        };
        addAndMakeVisible(b);
    };
    setupLatBtn(latZeroBtn_,  0);
    setupLatBtn(latMicroBtn_, 1);
    setupLatBtn(latPhaseBtn_, 2);
    setLatencyButtons(static_cast<int>(proc_.apvts.getRawParameterValue("latencyMode")->load()));

    bindKnob(sensitivity_, "sensitivity");
    bindKnob(retrigger_,   "retrigger");
    bindKnob(detail_,      "detail");
    addAndMakeVisible(outputMeter_);
    bindKnob(mix_,         "mix");

    // Bottom 8-slot Mixer
    for (int i = 0; i < pt2::SampleEngine::kNumSlots; ++i) {
        slots_[static_cast<size_t>(i)] = std::make_unique<pt2::MixerSlotComponent>(
            proc_, i, [this](int idx) {
                selectedSlot_ = idx;
                for (int j = 0; j < pt2::SampleEngine::kNumSlots; ++j)
                    if (slots_[static_cast<size_t>(j)]) slots_[static_cast<size_t>(j)]->setSelected(j == idx);
                velocityEditor_.bindSlot(idx);
            });
        addAndMakeVisible(*slots_[static_cast<size_t>(i)]);
    }
    slots_[0]->setSelected(true);

    addChildComponent(velocityEditor_);

    setTopTab(TopTab::Triggering);
    setBottomView(false);

    setResizable(true, true);
    setResizeLimits(960, 560, 1920, 1080);
    setSize(1160, 660);
    startTimerHz(30);
}

PulseTrigger2AudioProcessorEditor::~PulseTrigger2AudioProcessorEditor() {
    stopTimer();
    setLookAndFeel(nullptr);
}

void PulseTrigger2AudioProcessorEditor::timerCallback() {
    inputMeter_.setLevels(proc_.inputMeterL.load(std::memory_order_relaxed),
                          proc_.inputMeterR.load(std::memory_order_relaxed));
    outputMeter_.setLevels(proc_.outputMeterL.load(std::memory_order_relaxed),
                           proc_.outputMeterR.load(std::memory_order_relaxed));

    // Update pad trigger flashes
    for (int i = 0; i < pt2::SampleEngine::kNumSlots; ++i) {
        float fl = proc_.slotFlash[static_cast<size_t>(i)].load(std::memory_order_relaxed);
        if (slots_[static_cast<size_t>(i)]) slots_[static_cast<size_t>(i)]->setFlash(fl);
        if (fl > 0.01f) proc_.slotFlash[static_cast<size_t>(i)].store(fl * 0.78f, std::memory_order_relaxed);
    }

    // Update MIDI Capture button indicator
    const auto hits = proc_.getMidiCapture().getHitCount();
    midiCaptureBtn_.setButtonText(hits > 0 ? ("MIDI (" + juce::String(static_cast<int>(hits)) + ") CLEAR") : "MIDI CAPTURE");
    midiCaptureBtn_.setColour(juce::TextButton::buttonColourId,
                              hits > 0 ? pt2::PulseLookAndFeel::kAmberTrig.withAlpha(0.35f) : pt2::PulseLookAndFeel::kBgPanelHi);
}

void PulseTrigger2AudioProcessorEditor::setTopTab(TopTab tab) {
    currentTopTab_ = tab;
    const bool isTrig = (tab == TopTab::Triggering);
    browserBtn_.setToggleState(tab == TopTab::Browser, juce::dontSendNotification);
    triggeringBtn_.setToggleState(isTrig, juce::dontSendNotification);
    settingsBtn_.setToggleState(tab == TopTab::Settings, juce::dontSendNotification);

    browserPanel_.setVisible(tab == TopTab::Browser);
    settingsPanel_.setVisible(tab == TopTab::Settings);
    if (tab == TopTab::Browser)  browserPanel_.refreshFromProcessor();
    if (tab == TopTab::Settings) settingsPanel_.refreshStatus();

    gateBtn_.setVisible(isTrig);
    gateAtk_.setVisible(isTrig); gateHold_.setVisible(isTrig); gateRel_.setVisible(isTrig); gateRange_.setVisible(isTrig); keyListenBtn_.setVisible(isTrig);
    inputMeter_.setVisible(isTrig); inputVol_.setVisible(isTrig);
    lowCut_.setVisible(isTrig); highCut_.setVisible(isTrig); suppress_.setVisible(isTrig); bleedGain_.setVisible(isTrig);
    scope_.setVisible(isTrig);
    latencyTitle_.setVisible(isTrig);
    latZeroBtn_.setVisible(isTrig); latMicroBtn_.setVisible(isTrig); latPhaseBtn_.setVisible(isTrig);
    sensitivity_.setVisible(isTrig); retrigger_.setVisible(isTrig); detail_.setVisible(isTrig);
    outputMeter_.setVisible(isTrig); mix_.setVisible(isTrig);

    if (getWidth() > 0 && getHeight() > 0) resized();
}

void PulseTrigger2AudioProcessorEditor::setBottomView(bool showCurves) {
    showingCurves_ = showCurves;
    mixerBtn_.setToggleState(!showCurves, juce::dontSendNotification);
    curvesBtn_.setToggleState(showCurves, juce::dontSendNotification);
    for (auto& slot : slots_)
        if (slot) slot->setVisible(!showCurves);
    velocityEditor_.setVisible(showCurves);
    if (getWidth() > 0 && getHeight() > 0) resized();
}

void PulseTrigger2AudioProcessorEditor::setLatencyButtons(int modeIdx) {
    latZeroBtn_.setToggleState(modeIdx == 0, juce::dontSendNotification);
    latMicroBtn_.setToggleState(modeIdx == 1, juce::dontSendNotification);
    latPhaseBtn_.setToggleState(modeIdx == 2, juce::dontSendNotification);
}

void PulseTrigger2AudioProcessorEditor::savePresetDialog() {
    presetChooser_ = std::make_unique<juce::FileChooser>("Save PulseTrigger 2 Preset",
                                                         proc_.getBaseLibraryDir().getChildFile("MyDrumPreset.tprs"), "*.tprs");
    presetChooser_->launchAsync(juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles,
        [this](const juce::FileChooser& fc) {
            auto f = fc.getResult();
            if (f != juce::File()) {
                if (!f.hasFileExtension(".tprs")) f = f.withFileExtension(".tprs");
                proc_.savePresetToFile(f);
                browserPanel_.refreshFromProcessor();
            }
        });
}

void PulseTrigger2AudioProcessorEditor::paint(juce::Graphics& g) {
    auto b = getLocalBounds().toFloat();
    g.setGradientFill(juce::ColourGradient(pt2::PulseLookAndFeel::kBgPanelHi, 0.0f, 0.0f,
                                           pt2::PulseLookAndFeel::kBgChassis, 0.0f, b.getHeight(), false));
    g.fillAll();

    g.setColour(pt2::PulseLookAndFeel::kBorder);
    g.drawVerticalLine(138, 8.0f, b.getHeight() - 8.0f);

    if (currentTopTab_ == TopTab::Triggering) {
        g.setColour(pt2::PulseLookAndFeel::kTextMute);
        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        g.drawText(juce::String::fromUTF8("VST3 \xC2\xB7 AU \xC2\xB7 AAX"),
                   juce::Rectangle<int>(getWidth() - 108, 10, 96, 14), juce::Justification::centredRight);
    }
}

void PulseTrigger2AudioProcessorEditor::resized() {
    auto area = getLocalBounds().reduced(10);

    // Left sidebar (124px)
    auto sidebar = area.removeFromLeft(124);
    browserBtn_.setBounds(sidebar.removeFromTop(30).reduced(2));
    triggeringBtn_.setBounds(sidebar.removeFromTop(30).reduced(2));
    settingsBtn_.setBounds(sidebar.removeFromTop(30).reduced(2));

    sidebar.removeFromTop(36);
    mixerBtn_.setBounds(sidebar.removeFromTop(32).reduced(2));
    curvesBtn_.setBounds(sidebar.removeFromTop(32).reduced(2));

    dragMidiBtn_.setBounds(sidebar.removeFromBottom(34).reduced(2));
    midiCaptureBtn_.setBounds(sidebar.removeFromBottom(30).reduced(2));
    savePresetBtn_.setBounds(sidebar.removeFromBottom(30).reduced(2));
    flipPhasesBtn_.setBounds(sidebar.removeFromBottom(30).reduced(2));

    area.removeFromLeft(12);

    // Top Panel (46% height)
    auto topPanel = area.removeFromTop(static_cast<int>(area.getHeight() * 0.46f));
    browserPanel_.setBounds(topPanel);
    settingsPanel_.setBounds(topPanel);

    auto topLeft  = topPanel.removeFromLeft(286);
    auto topRight = topPanel.removeFromRight(268);
    scope_.setBounds(topPanel.reduced(8, 2));

    auto gateRow = topLeft.removeFromTop(68);
    auto gateBtns = gateRow.removeFromLeft(46);
    gateBtn_.setBounds(gateBtns.removeFromTop(32).reduced(1, 3));
    keyListenBtn_.setBounds(gateBtns.reduced(1, 3));
    const int gkW = gateRow.getWidth() / 4;
    gateAtk_.setBounds(gateRow.removeFromLeft(gkW));
    gateHold_.setBounds(gateRow.removeFromLeft(gkW));
    gateRel_.setBounds(gateRow.removeFromLeft(gkW));
    gateRange_.setBounds(gateRow);

    topLeft.removeFromTop(6);
    inputMeter_.setBounds(topLeft.removeFromLeft(48));
    topLeft.removeFromLeft(6);

    auto leftKnobsCol = topLeft;
    auto filterRow1 = leftKnobsCol.removeFromTop(leftKnobsCol.getHeight() / 2);
    const int fkW = filterRow1.getWidth() / 3;
    inputVol_.setBounds(filterRow1.removeFromLeft(fkW));
    lowCut_.setBounds(filterRow1.removeFromLeft(fkW));
    highCut_.setBounds(filterRow1);

    auto filterRow2 = leftKnobsCol;
    filterRow2.removeFromLeft(fkW);
    suppress_.setBounds(filterRow2.removeFromLeft(fkW));
    bleedGain_.setBounds(filterRow2);

    auto outCol = topRight.removeFromRight(66);
    outCol.removeFromTop(16);
    mix_.setBounds(outCol.removeFromBottom(68));
    outputMeter_.setBounds(outCol.reduced(8, 2));

    topRight.removeFromRight(6);
    latencyTitle_.setBounds(topRight.removeFromTop(16));
    auto latRow = topRight.removeFromTop(26);
    const int lw = latRow.getWidth() / 3;
    latZeroBtn_.setBounds(latRow.removeFromLeft(lw).reduced(1));
    latMicroBtn_.setBounds(latRow.removeFromLeft(lw).reduced(1));
    latPhaseBtn_.setBounds(latRow.reduced(1));

    topRight.removeFromTop(10);
    auto detRow1 = topRight.removeFromTop(topRight.getHeight() / 2);
    sensitivity_.setBounds(detRow1.withSizeKeepingCentre(78, detRow1.getHeight()));

    auto detRow2 = topRight;
    retrigger_.setBounds(detRow2.removeFromLeft(detRow2.getWidth() / 2));
    detail_.setBounds(detRow2);

    area.removeFromTop(10);

    // Bottom Panel
    if (showingCurves_) {
        velocityEditor_.setBounds(area);
    } else {
        const int slotW = area.getWidth() / pt2::SampleEngine::kNumSlots;
        for (int i = 0; i < pt2::SampleEngine::kNumSlots; ++i) {
            if (slots_[static_cast<size_t>(i)])
                slots_[static_cast<size_t>(i)]->setBounds(area.removeFromLeft(slotW));
        }
    }
}
