#pragma once
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_core/juce_core.h>
#include "../DSP/SampleEngine.h"
#include "SfzParser.h"

namespace pt2 {

// Pluggable loader supporting WAV, AIFF, FLAC (via JUCE AudioFormatManager),
// SFZ v1/v2 multi-velocity kits, and open .tkit archives.
// Always pre-decodes and resamples offline to targetSampleRate so real-time
// playback requires zero resampling CPU when Tune == 0.
class SampleLoader {
public:
    SampleLoader() {
        formatManager_.registerBasicFormats(); // WAV, AIFF, FLAC, OGG
    }

    bool loadSingleAudioFile(const juce::File& file, double targetSampleRate, LoadedSample& outSample) {
        std::unique_ptr<juce::AudioFormatReader> reader(formatManager_.createReaderFor(file));
        if (!reader || reader->lengthInSamples <= 0) return false;

        const int srcLen = static_cast<int>(reader->lengthInSamples);
        juce::AudioBuffer<float> raw(2, srcLen);
        raw.clear();
        reader->read(&raw, 0, srcLen, 0, true, reader->numChannels > 1);
        if (reader->numChannels == 1)
            raw.copyFrom(1, 0, raw, 0, 0, srcLen);

        const double ratio = reader->sampleRate / std::max(8000.0, targetSampleRate);
        const int dstLen = (std::abs(ratio - 1.0) < 1e-4)
            ? srcLen
            : std::max(1, static_cast<int>(std::lround(static_cast<double>(srcLen) / ratio)));

        outSample.name = file.getFileName().toStdString();
        outSample.left.resize(static_cast<size_t>(dstLen));
        outSample.right.resize(static_cast<size_t>(dstLen));

        if (std::abs(ratio - 1.0) < 1e-4) {
            std::copy_n(raw.getReadPointer(0), dstLen, outSample.left.data());
            std::copy_n(raw.getReadPointer(1), dstLen, outSample.right.data());
        } else {
            juce::LagrangeInterpolator interpL, interpR;
            interpL.process(ratio, raw.getReadPointer(0), outSample.left.data(), dstLen);
            interpR.process(ratio, raw.getReadPointer(1), outSample.right.data(), dstLen);
        }

        outSample.analyzeOffline(); // Offline Transient Trimming + RMS loudness
        return true;
    }

    // Loads an .sfz kit into a slot with full velocity & round-robin mapping.
    bool loadSfzKit(const juce::File& sfzFile, double targetSampleRate, SampleEngine::SlotData& slot) {
        if (!sfzFile.existsAsFile()) return false;
        const auto regions = SfzParser::parse(sfzFile.loadFileAsString().toStdString());
        if (regions.empty()) return false;

        slot.pool.clear();
        slot.zones.clear();

        const auto baseDir = sfzFile.getParentDirectory();
        for (const auto& r : regions) {
            const auto wavFile = baseDir.getChildFile(juce::String(r.samplePath));
            LoadedSample smp;
            if (!loadSingleAudioFile(wavFile, targetSampleRate, smp)) continue;

            const int smpIdx = static_cast<int>(slot.pool.size());
            slot.pool.push_back(std::move(smp));

            // Group regions sharing the same [lovel, hivel] into one round-robin zone
            bool merged = false;
            for (auto& z : slot.zones) {
                if (z.minVel == r.lovel && z.maxVel == r.hivel) {
                    z.sampleIndices.push_back(smpIdx);
                    merged = true;
                    break;
                }
            }
            if (!merged) {
                slot.zones.push_back({
                    "VEL " + std::to_string(r.lovel) + "-" + std::to_string(r.hivel),
                    r.lovel, r.hivel, { smpIdx }
                });
            }
        }
        return !slot.pool.empty();
    }

    // Runs Auto-Split by Loudness on all samples currently in a slot.
    static void autoSplitSlotByLoudness(SampleEngine::SlotData& slot) {
        std::vector<VelocityMapper::SampleLoudnessEntry> entries;
        entries.reserve(slot.pool.size());
        for (int i = 0; i < static_cast<int>(slot.pool.size()); ++i) {
            entries.push_back({ i, slot.pool[static_cast<size_t>(i)].rmsLoudness });
        }
        slot.zones = VelocityMapper::autoSplitByLoudness(std::move(entries));
    }

private:
    juce::AudioFormatManager formatManager_;
};

} // namespace pt2
