#pragma once
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include <cctype>

namespace pt2 {

struct SfzRegion {
    std::string samplePath;
    int lovel = 1;
    int hivel = 127;
    int seqLength = 1;
    int seqPosition = 1;
};

// Lightweight SFZ v1/v2 parser for loading multi-velocity and round-robin drum kits.
class SfzParser {
public:
    static std::vector<SfzRegion> parse(const std::string& sfzText) {
        std::vector<SfzRegion> regions;
        SfzRegion groupDefaults{};
        SfzRegion current{};
        bool inRegion = false;
        bool inGroup  = false;

        std::istringstream iss(sfzText);
        std::string line;
        while (std::getline(iss, line)) {
            // Strip // comments
            const auto commentPos = line.find("//");
            if (commentPos != std::string::npos) line = line.substr(0, commentPos);

            // Trim
            const auto first = line.find_first_not_of(" \t\r\n");
            if (first == std::string::npos) continue;
            line = line.substr(first);

            if (line.rfind("<group>", 0) == 0) {
                if (inRegion && !current.samplePath.empty()) regions.push_back(current);
                inRegion = false;
                inGroup = true;
                groupDefaults = SfzRegion{};
                line = line.substr(7);
            } else if (line.rfind("<region>", 0) == 0) {
                if (inRegion && !current.samplePath.empty()) regions.push_back(current);
                inRegion = true;
                inGroup = false;
                current = groupDefaults;
                line = line.substr(8);
            }

            SfzRegion& target = inRegion ? current : (inGroup ? groupDefaults : current);
            parseOpcodesOnLine(line, target);
        }
        if (inRegion && !current.samplePath.empty()) regions.push_back(current);
        return regions;
    }

private:
    static void parseOpcodesOnLine(const std::string& line, SfzRegion& r) {
        // Handle sample= opcode (may contain spaces until end of line)
        const auto smpPos = line.find("sample=");
        if (smpPos != std::string::npos) {
            std::string val = line.substr(smpPos + 7);
            const auto endTrim = val.find_last_not_of(" \t\r\n");
            if (endTrim != std::string::npos) val = val.substr(0, endTrim + 1);
            r.samplePath = val;
        }

        std::istringstream tok(line.substr(0, smpPos));
        std::string kv;
        while (tok >> kv) {
            const auto eq = kv.find('=');
            if (eq == std::string::npos) continue;
            const std::string key = kv.substr(0, eq);
            const std::string val = kv.substr(eq + 1);
            try {
                if (key == "lovel")        r.lovel = std::clamp(std::stoi(val), 1, 127);
                else if (key == "hivel")   r.hivel = std::clamp(std::stoi(val), 1, 127);
                else if (key == "seq_length")   r.seqLength = std::max(1, std::stoi(val));
                else if (key == "seq_position") r.seqPosition = std::max(1, std::stoi(val));
            } catch (...) {}
        }
    }
};

} // namespace pt2
