#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "../PluginProcessor.h"
#include "LookAndFeel.h"

namespace pt2 {

// Single vertical channel strip for the 8-slot mixer.
// Left-click pad = select & audition; Right-click pad = Load WAV/SFZ or Clear Slot;
// Drag & Drop WAV/SFZ onto the channel loads it across full 1-127 velocity range.
class MixerSlotComponent : public juce::Component, public juce::FileDragAndDropTarget {
public:
    MixerSlotComponent(PulseTrigger2AudioProcessor& p, int slotIdx, std::function<void(int)> onSelectSlot)
        : proc_(p), slotIdx_(slotIdx), onSelect_(std::move(onSelectSlot)),
          pan_("PAN"), tune_("TUNE") {
        const auto id = "slot" + juce::String(slotIdx + 1) + "_";

        title_.setText("SLOT " + juce::String(slotIdx + 1), juce::dontSendNotification);
        title_.setJustificationType(juce::Justification::centred);
        title_.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        title_.setColour(juce::Label::textColourId, PulseLookAndFeel::kTextMute);
        addAndMakeVisible(title_);

        addAndMakeVisible(pan_);
        addAndMakeVisible(tune_);

        vol_.setSliderStyle(juce::Slider::LinearVertical);
        vol_.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        addAndMakeVisible(vol_);

        solo_.setButtonText("S");
        solo_.setClickingTogglesState(true);
        solo_.setColour(juce::TextButton::buttonOnColourId, PulseLookAndFeel::kCobaltGlow);
        addAndMakeVisible(solo_);

        mute_.setButtonText("M");
        mute_.setClickingTogglesState(true);
        mute_.setColour(juce::TextButton::buttonOnColourId, PulseLookAndFeel::kRedBleed);
        addAndMakeVisible(mute_);

        phase_.setButtonText(juce::String::fromUTF8("\xC3\x98"));
        phase_.setClickingTogglesState(true);
        phase_.setColour(juce::TextButton::buttonOnColourId, PulseLookAndFeel::kAmberTrig);
        addAndMakeVisible(phase_);

        loadBtn_.setButtonText("+");
        loadBtn_.setTooltip("Load WAV / AIFF / FLAC / SFZ into Slot");
        loadBtn_.onClick = [this] { openFilePicker(); };
        addAndMakeVisible(loadBtn_);

        pad_.setColour(juce::TextButton::buttonColourId, PulseLookAndFeel::kBgChassis);
        pad_.onClick = [this] {
            if (onSelect_) onSelect_(slotIdx_);
            proc_.auditionSlotZone(slotIdx_, 2);
        };
        addAndMakeVisible(pad_);

        panAtt_   = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc_.apvts, id + "pan", pan_.slider);
        tuneAtt_  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc_.apvts, id + "tune", tune_.slider);
        volAtt_   = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc_.apvts, id + "vol", vol_);
        soloAtt_  = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(proc_.apvts, id + "solo", solo_);
        muteAtt_  = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(proc_.apvts, id + "mute", mute_);
        phaseAtt_ = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(proc_.apvts, id + "phase", phase_);

        refreshLabel();
    }

    void setSelected(bool sel) { selected_ = sel; repaint(); }

    void setFlash(float level) {
        if (std::abs(flash_ - level) > 0.02f) {
            flash_ = level;
            repaint();
        }
    }

    void refreshLabel() {
        pad_.setButtonText(proc_.getSlotDisplayName(slotIdx_));
        const bool hasSamples = !proc_.getSampleEngine().getSlot(slotIdx_).pool.empty();
        pad_.setColour(juce::TextButton::buttonColourId,
                       hasSamples ? PulseLookAndFeel::kCobalt.withAlpha(0.28f) : PulseLookAndFeel::kBgChassis);
        repaint();
    }

    void paint(juce::Graphics& g) override {
        auto r = getLocalBounds().toFloat().reduced(2.0f);
        g.setGradientFill(juce::ColourGradient(PulseLookAndFeel::kBgPanelHi, r.getX(), r.getY(),
                                               PulseLookAndFeel::kBgPanel,   r.getX(), r.getBottom(), false));
        g.fillRoundedRectangle(r, 5.0f);
        g.setColour(selected_ ? PulseLookAndFeel::kCyanWave : PulseLookAndFeel::kBorder);
        g.drawRoundedRectangle(r, 5.0f, selected_ ? 1.5f : 1.0f);

        g.setColour(PulseLookAndFeel::kBgScope.withAlpha(0.6f));
        g.fillRoundedRectangle(r.getX() + 6.0f, r.getY() + 5.0f, r.getWidth() - 12.0f, 18.0f, 3.0f);

        const auto faderR = vol_.getBounds();
        if (faderR.getHeight() > 40) {
            g.setColour(PulseLookAndFeel::kTextMute.withAlpha(0.75f));
            g.setFont(juce::FontOptions(9.0f));
            static const char* kTicks[5] = { "+12", "0", "-10", "-24", "-60" };
            for (int i = 0; i < 5; ++i) {
                const int ty = faderR.getY() + 4 + (i * (faderR.getHeight() - 16)) / 4;
                g.drawText(kTicks[i], juce::Rectangle<float>(r.getX() + 4.0f, static_cast<float>(ty), 22.0f, 10.0f), juce::Justification::centredRight);
            }
        }
    }

    void paintOverChildren(juce::Graphics& g) override {
        if (flash_ > 0.05f) {
            auto pb = pad_.getBounds().toFloat().reduced(1.0f);
            g.setColour(PulseLookAndFeel::kCyanWave.withAlpha(flash_ * 0.55f));
            g.fillRoundedRectangle(pb, 4.0f);
            g.setColour(PulseLookAndFeel::kCyanWave.withAlpha(flash_));
            g.drawRoundedRectangle(pb, 4.0f, 2.0f);
        }
    }

    void resized() override {
        auto r = getLocalBounds().reduced(6);
        auto hdr = r.removeFromTop(20);
        loadBtn_.setBounds(hdr.removeFromRight(20).reduced(1));
        title_.setBounds(hdr);
        r.removeFromTop(4);

        auto topKnobs = r.removeFromTop(54);
        pan_.setBounds(topKnobs.removeFromLeft(topKnobs.getWidth() / 2));
        tune_.setBounds(topKnobs);

        r.removeFromTop(6);
        pad_.setBounds(r.removeFromBottom(38));
        r.removeFromBottom(6);

        auto rightBtns = r.removeFromRight(32);
        const int btnH = 26;
        solo_.setBounds(rightBtns.removeFromTop(btnH).reduced(2));
        rightBtns.removeFromTop(4);
        mute_.setBounds(rightBtns.removeFromTop(btnH).reduced(2));
        rightBtns.removeFromTop(4);
        phase_.setBounds(rightBtns.removeFromTop(btnH).reduced(2));

        r.removeFromLeft(18);
        vol_.setBounds(r);
    }

    bool isInterestedInFileDrag(const juce::StringArray&) override { return true; }
    void filesDropped(const juce::StringArray& files, int, int) override {
        if (proc_.loadFilesIntoSlotZone(slotIdx_, -1, files)) {
            refreshLabel();
            if (onSelect_) onSelect_(slotIdx_);
        }
    }

private:
    void openFilePicker() {
        chooser_ = std::make_unique<juce::FileChooser>("Load Sample or SFZ into Slot " + juce::String(slotIdx_ + 1),
                                                       proc_.getBaseLibraryDir(), "*.wav;*.aif;*.aiff;*.flac;*.sfz");
        chooser_->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles
                              | juce::FileBrowserComponent::canSelectMultipleItems,
            [this](const juce::FileChooser& fc) {
                juce::StringArray paths;
                for (const auto& f : fc.getResults()) paths.add(f.getFullPathName());
                if (!paths.isEmpty() && proc_.loadFilesIntoSlotZone(slotIdx_, -1, paths)) {
                    refreshLabel();
                    if (onSelect_) onSelect_(slotIdx_);
                }
            });
    }

    PulseTrigger2AudioProcessor& proc_;
    int slotIdx_;
    bool selected_ = false;
    float flash_ = 0.0f;
    std::function<void(int)> onSelect_;
    std::unique_ptr<juce::FileChooser> chooser_;

    juce::Label title_;
    LabeledKnob pan_, tune_;
    juce::Slider vol_;
    juce::TextButton loadBtn_, solo_, mute_, phase_, pad_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> panAtt_, tuneAtt_, volAtt_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> soloAtt_, muteAtt_, phaseAtt_;
};

} // namespace pt2
