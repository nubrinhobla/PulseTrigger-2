#pragma once
#include <juce_gui_basics/juce_gui_basics.h>

namespace pt2 {

// Dark anodized slate-grey brushed metal LookAndFeel matching the approved PulseTrigger 2 mockup.
class PulseLookAndFeel : public juce::LookAndFeel_V4 {
public:
    static inline const juce::Colour kBgChassis   { 0xFF171B21 };
    static inline const juce::Colour kBgPanel     { 0xFF20262F };
    static inline const juce::Colour kBgPanelHi   { 0xFF272F3A };
    static inline const juce::Colour kBgScope     { 0xFF090C10 };
    static inline const juce::Colour kBorder      { 0xFF343E4D };
    static inline const juce::Colour kTextMain    { 0xFFE6EDF3 };
    static inline const juce::Colour kTextMute    { 0xFF8C9AAD };
    static inline const juce::Colour kCobalt      { 0xFF0284C7 };
    static inline const juce::Colour kCobaltGlow  { 0xFF2563EB };
    static inline const juce::Colour kCyanWave    { 0xFF38BDF8 };
    static inline const juce::Colour kAmberTrig   { 0xFFF97316 };
    static inline const juce::Colour kRedBleed    { 0xFFDC2626 };
    static inline const juce::Colour kTealSoft    { 0xFF0D9488 };

    PulseLookAndFeel() {
        setColour(juce::ResizableWindow::backgroundColourId, kBgChassis);
        setColour(juce::TextButton::buttonColourId, kBgPanelHi);
        setColour(juce::TextButton::buttonOnColourId, kCobaltGlow);
        setColour(juce::TextButton::textColourOffId, kTextMain);
        setColour(juce::TextButton::textColourOnId, juce::Colours::white);
        setColour(juce::Label::textColourId, kTextMain);
    }

    void drawButtonBackground(juce::Graphics& g, juce::Button& button,
                              const juce::Colour& bgColour, bool isOver, bool isDown) override {
        auto r = button.getLocalBounds().toFloat().reduced(0.5f);
        auto base = bgColour;
        if (button.getToggleState()) base = button.findColour(juce::TextButton::buttonOnColourId);
        if (isDown)      base = base.darker(0.15f);
        else if (isOver) base = base.brighter(0.10f);

        g.setGradientFill(juce::ColourGradient(base.brighter(0.12f), r.getX(), r.getY(),
                                               base.darker(0.18f),   r.getX(), r.getBottom(), false));
        g.fillRoundedRectangle(r, 4.0f);
        g.setColour(button.getToggleState() ? kCyanWave.withAlpha(0.8f) : kBorder);
        g.drawRoundedRectangle(r, 4.0f, 1.0f);
    }

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                          juce::Slider&) override {
        const float radius = static_cast<float>(juce::jmin(width, height)) * 0.44f;
        const float cx = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
        const float cy = static_cast<float>(y) + static_cast<float>(height) * 0.5f;
        const float angle = rotaryStartAngle + sliderPos * (rotaryEndAngle - rotaryStartAngle);

        // Recessed well
        g.setColour(kBgScope);
        g.fillEllipse(cx - radius, cy - radius, radius * 2.0f, radius * 2.0f);

        // Background track arc
        juce::Path bgArc;
        bgArc.addCentredArc(cx, cy, radius - 1.5f, radius - 1.5f, 0.0f, rotaryStartAngle, rotaryEndAngle, true);
        g.setColour(kBorder.withAlpha(0.7f));
        g.strokePath(bgArc, juce::PathStrokeType(2.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // Active cobalt-cyan value arc
        juce::Path valArc;
        valArc.addCentredArc(cx, cy, radius - 1.5f, radius - 1.5f, 0.0f, rotaryStartAngle, angle, true);
        g.setColour(kCyanWave);
        g.strokePath(valArc, juce::PathStrokeType(2.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // Brushed metallic knob cap
        const float capR = radius * 0.72f;
        g.setGradientFill(juce::ColourGradient(juce::Colour(0xFF64748B), cx - capR, cy - capR,
                                               juce::Colour(0xFF1E242C), cx + capR, cy + capR, false));
        g.fillEllipse(cx - capR, cy - capR, capR * 2.0f, capR * 2.0f);
        g.setColour(juce::Colour(0xFF94A3B8).withAlpha(0.35f));
        g.drawEllipse(cx - capR, cy - capR, capR * 2.0f, capR * 2.0f, 1.0f);

        // Inner recessed face
        const float innerR = capR * 0.78f;
        g.setGradientFill(juce::ColourGradient(juce::Colour(0xFF2B323C), cx, cy - innerR,
                                               juce::Colour(0xFF3E4754), cx, cy + innerR, false));
        g.fillEllipse(cx - innerR, cy - innerR, innerR * 2.0f, innerR * 2.0f);

        // Crisp white pointer
        juce::Path p;
        p.addRoundedRectangle(-1.2f, -capR + 1.5f, 2.4f, capR * 0.56f, 1.0f);
        p.applyTransform(juce::AffineTransform::rotation(angle).translated(cx, cy));
        g.setColour(juce::Colours::white);
        g.fillPath(p);
    }

    void drawLinearSlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPos, float, float,
                          const juce::Slider::SliderStyle style, juce::Slider&) override {
        if (style != juce::Slider::LinearVertical) return;

        const float cx = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
        const float top = static_cast<float>(y) + 6.0f;
        const float bot = static_cast<float>(y + height) - 6.0f;

        // Fader slot track
        g.setColour(kBgScope);
        g.fillRoundedRectangle(cx - 2.5f, top, 5.0f, bot - top, 2.5f);

        // Cobalt-cyan active level fill from bottom to thumb
        const float clampedPos = juce::jlimit(top, bot, sliderPos);
        g.setColour(kCyanWave);
        g.fillRoundedRectangle(cx - 2.0f, clampedPos, 4.0f, bot - clampedPos, 2.0f);

        // Precision metallic fader cap
        const float capW = 20.0f, capH = 26.0f;
        juce::Rectangle<float> cap(cx - capW * 0.5f, clampedPos - capH * 0.5f, capW, capH);
        g.setGradientFill(juce::ColourGradient(juce::Colour(0xFF94A3B8), cap.getX(), cap.getY(),
                                               juce::Colour(0xFF334155), cap.getX(), cap.getBottom(), false));
        g.fillRoundedRectangle(cap, 3.0f);
        g.setColour(kBgScope);
        g.drawRoundedRectangle(cap, 3.0f, 1.0f);
        g.setColour(juce::Colours::white.withAlpha(0.85f));
        g.drawLine(cap.getX() + 3.0f, clampedPos, cap.getRight() - 3.0f, clampedPos, 1.5f);
    }
};

// Labeled rotary knob helper (always paints a clean crisp label below the knob).
class LabeledKnob : public juce::Component {
public:
    LabeledKnob(const juce::String& labelText = {}) {
        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        addAndMakeVisible(slider);

        label.setText(labelText, juce::dontSendNotification);
        label.setJustificationType(juce::Justification::centred);
        label.setFont(juce::FontOptions(10.5f, juce::Font::bold));
        label.setColour(juce::Label::textColourId, PulseLookAndFeel::kTextMute);
        addAndMakeVisible(label);
    }

    void resized() override {
        auto r = getLocalBounds();
        label.setBounds(r.removeFromBottom(15));
        slider.setBounds(r);
    }

    juce::Slider slider;
    juce::Label label;
};

// Vertical stereo segmented LED meter (0 to -48 dB) matching the approved mockup.
class StereoLedMeter : public juce::Component {
public:
    explicit StereoLedMeter(const juce::String& titleText) : title_(titleText) {}

    void setLevels(float l, float r) noexcept {
        levelL_ = std::max(l, levelL_ * 0.86f);
        levelR_ = std::max(r, levelR_ * 0.86f);
        repaint();
    }

    void paint(juce::Graphics& g) override {
        auto b = getLocalBounds().toFloat();
        g.setColour(PulseLookAndFeel::kTextMute);
        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        g.drawText(title_, b.removeFromTop(14.0f), juce::Justification::centred);

        auto meterBox = b.reduced(2.0f, 2.0f);
        g.setColour(PulseLookAndFeel::kBgScope);
        g.fillRoundedRectangle(meterBox, 3.0f);
        g.setColour(PulseLookAndFeel::kBorder);
        g.drawRoundedRectangle(meterBox, 3.0f, 1.0f);

        auto inner = meterBox.reduced(4.0f);
        const float colW = (inner.getWidth() - 4.0f) * 0.5f;
        drawBar(g, { inner.getX(), inner.getY(), colW, inner.getHeight() }, levelL_);
        drawBar(g, { inner.getX() + colW + 4.0f, inner.getY(), colW, inner.getHeight() }, levelR_);
    }

private:
    static void drawBar(juce::Graphics& g, juce::Rectangle<float> r, float lin) {
        const float db = (lin > 1e-4f) ? 20.0f * std::log10(lin) : -60.0f;
        const float norm = juce::jlimit(0.0f, 1.0f, (db + 48.0f) / 48.0f);
        constexpr int segs = 18;
        const float segH = (r.getHeight() - (segs - 1) * 1.5f) / static_cast<float>(segs);

        for (int i = 0; i < segs; ++i) {
            const float frac = static_cast<float>(i + 1) / static_cast<float>(segs);
            const float sy = r.getBottom() - static_cast<float>(i + 1) * segH - static_cast<float>(i) * 1.5f;
            const bool lit = (norm >= frac - 0.03f);
            juce::Colour c = (frac > 0.88f) ? PulseLookAndFeel::kAmberTrig
                           : (frac > 0.65f) ? PulseLookAndFeel::kCyanWave
                                            : PulseLookAndFeel::kCobalt;
            g.setColour(lit ? c : PulseLookAndFeel::kBgPanelHi.withAlpha(0.5f));
            g.fillRoundedRectangle(r.getX(), sy, r.getWidth(), segH, 1.0f);
        }
    }

    juce::String title_;
    float levelL_ = 0.0f, levelR_ = 0.0f;
};

} // namespace pt2
