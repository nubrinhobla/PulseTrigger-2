#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "../PluginProcessor.h"
#include "LookAndFeel.h"

namespace pt2 {

// Fully functional BROWSER tab: select library folder, refresh, 1-click Audition,
// list WAV/AIFF/FLAC/SFZ/TPRS files, double-click or click button to load into selected slot.
class BrowserPanel : public juce::Component, public juce::ListBoxModel {
public:
    BrowserPanel(PulseTrigger2AudioProcessor& p, std::function<int()> getSelectedSlot, std::function<void()> onSlotChanged)
        : proc_(p), getSelectedSlot_(std::move(getSelectedSlot)), onSlotChanged_(std::move(onSlotChanged)) {

        selectDirBtn_.setButtonText("SELECT LIBRARY FOLDER");
        selectDirBtn_.onClick = [this] { chooseBaseFolder(); };
        addAndMakeVisible(selectDirBtn_);

        refreshBtn_.setButtonText("REFRESH");
        refreshBtn_.onClick = [this] { scanDirectory(); };
        addAndMakeVisible(refreshBtn_);

        auditionBtn_.setButtonText("AUDITION");
        auditionBtn_.setClickingTogglesState(true);
        auditionBtn_.setToggleState(true, juce::dontSendNotification);
        addAndMakeVisible(auditionBtn_);

        loadToSlotBtn_.setButtonText("LOAD TO SELECTED SLOT");
        loadToSlotBtn_.setColour(juce::TextButton::buttonColourId, PulseLookAndFeel::kCobaltGlow);
        loadToSlotBtn_.onClick = [this] { loadSelectedFile(); };
        addAndMakeVisible(loadToSlotBtn_);

        pathLabel_.setColour(juce::Label::textColourId, PulseLookAndFeel::kTextMute);
        pathLabel_.setFont(juce::FontOptions(11.0f));
        addAndMakeVisible(pathLabel_);

        fileList_.setModel(this);
        fileList_.setRowHeight(24);
        fileList_.setColour(juce::ListBox::backgroundColourId, PulseLookAndFeel::kBgScope);
        fileList_.setColour(juce::ListBox::outlineColourId, PulseLookAndFeel::kBorder);
        fileList_.setOutlineThickness(1);
        addAndMakeVisible(fileList_);

        baseDir_ = proc_.getBaseLibraryDir();
        scanDirectory();
    }

    void paint(juce::Graphics& g) override {
        auto r = getLocalBounds().toFloat().reduced(2.0f);
        g.setColour(PulseLookAndFeel::kBgPanel);
        g.fillRoundedRectangle(r, 5.0f);
        g.setColour(PulseLookAndFeel::kBorder);
        g.drawRoundedRectangle(r, 5.0f, 1.0f);
    }

    void resized() override {
        auto r = getLocalBounds().reduced(10);
        auto topBar = r.removeFromTop(28);
        selectDirBtn_.setBounds(topBar.removeFromLeft(170).reduced(2));
        refreshBtn_.setBounds(topBar.removeFromLeft(80).reduced(2));
        auditionBtn_.setBounds(topBar.removeFromLeft(86).reduced(2));
        loadToSlotBtn_.setBounds(topBar.removeFromRight(180).reduced(2));

        pathLabel_.setBounds(r.removeFromTop(20));
        r.removeFromTop(4);
        fileList_.setBounds(r);
    }

    int getNumRows() override { return files_.size(); }

    void paintListBoxItem(int row, juce::Graphics& g, int width, int height, bool selected) override {
        if (row < 0 || row >= files_.size()) return;
        if (selected) {
            g.setColour(PulseLookAndFeel::kCobalt.withAlpha(0.35f));
            g.fillRect(0, 0, width, height);
        }
        const auto& f = files_.getReference(row);
        const bool isPreset = f.hasFileExtension(".tprs");
        g.setColour(isPreset ? PulseLookAndFeel::kAmberTrig : PulseLookAndFeel::kTextMain);
        g.setFont(juce::FontOptions(12.5f));
        const juce::String prefix = isPreset ? "[PRESET]  " : (f.hasFileExtension(".sfz") ? "[SFZ KIT] " : "[SAMPLE]  ");
        g.drawText(prefix + f.getFileName(), 8, 0, width - 16, height, juce::Justification::centredLeft);
    }

    void listBoxItemClicked(int row, const juce::MouseEvent&) override {
        if (row < 0 || row >= files_.size()) return;
        if (auditionBtn_.getToggleState()) {
            const auto& f = files_.getReference(row);
            if (!f.hasFileExtension(".tprs")) proc_.auditionPreviewFile(f);
        }
    }

    void listBoxItemDoubleClicked(int row, const juce::MouseEvent&) override {
        fileList_.selectRow(row);
        loadSelectedFile();
    }

    void refreshFromProcessor() {
        baseDir_ = proc_.getBaseLibraryDir();
        scanDirectory();
    }

private:
    void chooseBaseFolder() {
        chooser_ = std::make_unique<juce::FileChooser>("Select Sample Library Folder", baseDir_);
        chooser_->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectDirectories,
            [this](const juce::FileChooser& fc) {
                auto dir = fc.getResult();
                if (dir.isDirectory()) {
                    baseDir_ = dir;
                    proc_.setBaseLibraryDir(dir);
                    scanDirectory();
                }
            });
    }

    void scanDirectory() {
        files_.clear();
        pathLabel_.setText("Library: " + baseDir_.getFullPathName(), juce::dontSendNotification);
        if (baseDir_.isDirectory()) {
            baseDir_.findChildFiles(files_, juce::File::findFiles, true, "*.wav;*.aif;*.aiff;*.flac;*.sfz;*.tprs");
            files_.sort();
        }
        fileList_.updateContent();
        repaint();
    }

    void loadSelectedFile() {
        const int row = fileList_.getSelectedRow();
        if (row < 0 || row >= files_.size()) return;
        const auto& f = files_.getReference(row);
        if (f.hasFileExtension(".tprs")) {
            proc_.loadPresetFromFile(f);
        } else {
            const int slotIdx = getSelectedSlot_ ? getSelectedSlot_() : 0;
            proc_.loadFilesIntoSlotZone(slotIdx, 2, { f.getFullPathName() });
        }
        if (onSlotChanged_) onSlotChanged_();
    }

    PulseTrigger2AudioProcessor& proc_;
    std::function<int()> getSelectedSlot_;
    std::function<void()> onSlotChanged_;
    juce::File baseDir_;
    juce::Array<juce::File> files_;
    std::unique_ptr<juce::FileChooser> chooser_;

    juce::TextButton selectDirBtn_, refreshBtn_, auditionBtn_, loadToSlotBtn_;
    juce::Label pathLabel_;
    juce::ListBox fileList_;
};

} // namespace pt2
