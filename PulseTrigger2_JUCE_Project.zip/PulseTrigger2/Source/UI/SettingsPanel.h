#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "../PluginProcessor.h"
#include "LookAndFeel.h"

namespace pt2 {

// Fully functional SETTINGS tab: Bleed routing mode (Stereo L/R vs Sidechain),
// MIDI Out enable, MIDI Channel (1-16), MIDI Note (0-127), Base Directory, and live DSP status.
class SettingsPanel : public juce::Component {
public:
    explicit SettingsPanel(PulseTrigger2AudioProcessor& p) : proc_(p) {
        header_.setText("ENGINE & MIDI SETTINGS", juce::dontSendNotification);
        header_.setFont(juce::FontOptions(13.0f, juce::Font::bold));
        addAndMakeVisible(header_);

        stereoBleedBtn_.setButtonText("CLASSIC STEREO L/R BLEED MODE (L = Source, R = Bleed)");
        stereoBleedBtn_.setClickingTogglesState(true);
        addAndMakeVisible(stereoBleedBtn_);
        stereoBleedAtt_ = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(proc_.apvts, "stereoLRBleed", stereoBleedBtn_);

        midiOutBtn_.setButtonText("ENABLE REAL-TIME MIDI OUTPUT");
        midiOutBtn_.setClickingTogglesState(true);
        addAndMakeVisible(midiOutBtn_);
        midiOutAtt_ = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(proc_.apvts, "midiOutOn", midiOutBtn_);

        midiChLabel_.setText("MIDI CHANNEL (1-16):", juce::dontSendNotification);
        midiChLabel_.setColour(juce::Label::textColourId, PulseLookAndFeel::kTextMute);
        addAndMakeVisible(midiChLabel_);

        midiChSlider_.setSliderStyle(juce::Slider::IncDecButtons);
        midiChSlider_.setTextBoxStyle(juce::Slider::TextBoxLeft, false, 48, 22);
        addAndMakeVisible(midiChSlider_);
        midiChAtt_ = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc_.apvts, "midiChannel", midiChSlider_);

        midiNoteLabel_.setText("MIDI NOTE (36=Kick, 38=Snare):", juce::dontSendNotification);
        midiNoteLabel_.setColour(juce::Label::textColourId, PulseLookAndFeel::kTextMute);
        addAndMakeVisible(midiNoteLabel_);

        midiNoteSlider_.setSliderStyle(juce::Slider::IncDecButtons);
        midiNoteSlider_.setTextBoxStyle(juce::Slider::TextBoxLeft, false, 48, 22);
        addAndMakeVisible(midiNoteSlider_);
        midiNoteAtt_ = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc_.apvts, "midiNote", midiNoteSlider_);

        statusLabel_.setColour(juce::Label::textColourId, PulseLookAndFeel::kCyanWave);
        statusLabel_.setFont(juce::FontOptions(12.0f));
        addAndMakeVisible(statusLabel_);
        refreshStatus();
    }

    void refreshStatus() {
        const int lat = proc_.getLatencySamples();
        const double sr = proc_.getSampleRate() > 0.0 ? proc_.getSampleRate() : 44100.0;
        const double ms = (static_cast<double>(lat) / sr) * 1000.0;
        statusLabel_.setText("Active Sample Rate: " + juce::String(sr, 0) + " Hz  |  Reported Latency (PDC): "
                             + juce::String(lat) + " samples (" + juce::String(ms, 2) + " ms)  |  O(1) Time-Domain Engine (Zero FFT)",
                             juce::dontSendNotification);
    }

    void paint(juce::Graphics& g) override {
        auto r = getLocalBounds().toFloat().reduced(2.0f);
        g.setColour(PulseLookAndFeel::kBgPanel);
        g.fillRoundedRectangle(r, 5.0f);
        g.setColour(PulseLookAndFeel::kBorder);
        g.drawRoundedRectangle(r, 5.0f, 1.0f);
    }

    void resized() override {
        auto r = getLocalBounds().reduced(16);
        header_.setBounds(r.removeFromTop(24));
        r.removeFromTop(8);

        auto row1 = r.removeFromTop(30);
        stereoBleedBtn_.setBounds(row1.removeFromLeft(380).reduced(2));
        row1.removeFromLeft(16);
        midiOutBtn_.setBounds(row1.removeFromLeft(260).reduced(2));

        r.removeFromTop(12);
        auto row2 = r.removeFromTop(28);
        midiChLabel_.setBounds(row2.removeFromLeft(150));
        midiChSlider_.setBounds(row2.removeFromLeft(110));
        row2.removeFromLeft(24);
        midiNoteLabel_.setBounds(row2.removeFromLeft(210));
        midiNoteSlider_.setBounds(row2.removeFromLeft(110));

        r.removeFromTop(18);
        statusLabel_.setBounds(r.removeFromTop(24));
    }

private:
    PulseTrigger2AudioProcessor& proc_;
    juce::Label header_, midiChLabel_, midiNoteLabel_, statusLabel_;
    juce::TextButton stereoBleedBtn_, midiOutBtn_;
    juce::Slider midiChSlider_, midiNoteSlider_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> stereoBleedAtt_, midiOutAtt_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> midiChAtt_, midiNoteAtt_;
};

} // namespace pt2
