#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "../PluginProcessor.h"
#include "LookAndFeel.h"

namespace pt2 {

class OscilloscopeComponent : public juce::Component, private juce::Timer {
public:
    explicit OscilloscopeComponent(PulseTrigger2AudioProcessor& p) : proc_(p) {
        startTimerHz(60);
    }

    void paint(juce::Graphics& g) override {
        auto b = getLocalBounds().toFloat();
        g.setColour(PulseLookAndFeel::kBgScope);
        g.fillRoundedRectangle(b, 5.0f);
        g.setColour(PulseLookAndFeel::kBorder);
        g.drawRoundedRectangle(b, 5.0f, 1.5f);

        auto inner = b.reduced(3.0f);
        const float w = inner.getWidth();
        const float h = inner.getHeight();
        const float midY = inner.getCentreY();
        const float halfH = h * 0.44f;

        g.setColour(PulseLookAndFeel::kBorder.withAlpha(0.28f));
        g.drawHorizontalLine(static_cast<int>(midY), inner.getX(), inner.getRight());
        for (int i = 1; i < 10; ++i)
            g.drawVerticalLine(static_cast<int>(inner.getX() + w * (i / 10.0f)), inner.getY(), inner.getBottom());

        // Exact DSP threshold match from TransientDetector::detailToThreshold
        const float detailVal = proc_.apvts.getRawParameterValue("detail")->load();
        const float threshY = TransientDetector::detailToThreshold(detailVal) * halfH;
        g.setColour(PulseLookAndFeel::kRedBleed.withAlpha(0.14f));
        g.fillRect(inner.getX(), midY - threshY, w, threshY * 2.0f);

        const int wp = proc_.scopeWritePos.load(std::memory_order_acquire);
        const int N = PulseTrigger2AudioProcessor::kScopeSize;

        for (int i = 0; i < N; ++i) {
            const int idx = (wp + i) % N;
            const auto& f = proc_.scopeRing[static_cast<size_t>(idx)];
            const float x = inner.getX() + (static_cast<float>(i) / static_cast<float>(N)) * w;

            if (f.bleedPeak > 0.005f) {
                const float bh = std::min(1.0f, f.bleedPeak) * halfH;
                g.setColour(PulseLookAndFeel::kRedBleed.withAlpha(0.55f));
                g.drawVerticalLine(static_cast<int>(x), midY - bh, midY + bh);
            }

            const float wh = std::min(1.0f, f.wavePeak) * halfH;
            g.setColour(f.gateOpen ? PulseLookAndFeel::kCyanWave : PulseLookAndFeel::kCobalt.withAlpha(0.45f));
            g.drawVerticalLine(static_cast<int>(x), midY - wh, midY + wh);

            if (f.triggered) {
                g.setColour(PulseLookAndFeel::kAmberTrig);
                g.drawVerticalLine(static_cast<int>(x), inner.getY() + 2.0f, inner.getBottom() - 2.0f);
                juce::Path tri;
                tri.addTriangle(x - 4.0f, inner.getY() + 2.0f, x + 4.0f, inner.getY() + 2.0f, x, inner.getY() + 10.0f);
                g.fillPath(tri);
            }
        }

        g.setColour(juce::Colours::white.withAlpha(0.9f));
        g.drawHorizontalLine(static_cast<int>(midY - threshY), inner.getX(), inner.getRight());
        g.drawHorizontalLine(static_cast<int>(midY + threshY), inner.getX(), inner.getRight());

        g.setFont(juce::FontOptions(10.0f, juce::Font::bold));
        g.setColour(PulseLookAndFeel::kRedBleed.brighter(0.25f));
        g.drawText("BLEED SUPPRESSION", juce::Rectangle<float>(inner.getX() + 8.0f, inner.getY() + 4.0f, 140.0f, 14.0f), juce::Justification::centredLeft);

        g.setColour(PulseLookAndFeel::kAmberTrig);
        g.drawText("TRIG", juce::Rectangle<float>(inner.getRight() - 48.0f, inner.getY() + 4.0f, 40.0f, 14.0f), juce::Justification::centredRight);

        g.setColour(juce::Colours::white.withAlpha(0.85f));
        g.drawText("THRESHOLD", juce::Rectangle<float>(inner.getRight() - 74.0f, midY - threshY - 14.0f, 68.0f, 12.0f), juce::Justification::centredRight);
    }

private:
    void timerCallback() override { repaint(); }
    PulseTrigger2AudioProcessor& proc_;
};

} // namespace pt2
