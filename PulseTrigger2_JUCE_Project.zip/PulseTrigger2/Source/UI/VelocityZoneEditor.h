#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "../PluginProcessor.h"
#include "LookAndFeel.h"

namespace pt2 {

// Visual Velocity & Layer Mapper (CURVES tab):
// - Click '+ DROP WAV' on any lane to open file picker OR drag & drop WAVs directly onto the lane
// - Click anywhere on the lane to audition that velocity band
// - Click 'AUTO-SPLIT BY LOUDNESS' to auto-sort samples by RMS into Soft/Medium/Hard
class VelocityZoneEditor : public juce::Component, public juce::FileDragAndDropTarget, private juce::Timer {
public:
    explicit VelocityZoneEditor(PulseTrigger2AudioProcessor& p)
        : proc_(p),
          velKnob_("VELOCITY"), dynKnob_("DYNAMICS"), xfKnob_("CROSSFADE"),
          atkKnob_("ATTACK"), susKnob_("SUSTAIN"), relKnob_("RELEASE") {
        autoSplitBtn_.setButtonText("AUTO-SPLIT BY LOUDNESS");
        autoSplitBtn_.setColour(juce::TextButton::buttonColourId, PulseLookAndFeel::kCobaltGlow);
        autoSplitBtn_.onClick = [this] {
            proc_.autoSplitSlot(activeSlot_);
            repaint();
        };
        addAndMakeVisible(autoSplitBtn_);

        addAndMakeVisible(velKnob_);
        addAndMakeVisible(dynKnob_);
        addAndMakeVisible(xfKnob_);
        addAndMakeVisible(atkKnob_);
        addAndMakeVisible(susKnob_);
        addAndMakeVisible(relKnob_);

        bindSlot(0);
        startTimerHz(30);
    }

    void bindSlot(int slotIdx) {
        activeSlot_ = std::clamp(slotIdx, 0, SampleEngine::kNumSlots - 1);
        const auto id = "slot" + juce::String(activeSlot_ + 1) + "_";
        velAtt_.reset(); dynAtt_.reset(); xfAtt_.reset();
        atkAtt_.reset(); susAtt_.reset(); relAtt_.reset();
        velAtt_ = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc_.apvts, id + "velCurve",  velKnob_.slider);
        dynAtt_ = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc_.apvts, id + "dynamics",  dynKnob_.slider);
        xfAtt_  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc_.apvts, id + "crossfade", xfKnob_.slider);
        atkAtt_ = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc_.apvts, id + "attack",    atkKnob_.slider);
        susAtt_ = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc_.apvts, id + "sustain",   susKnob_.slider);
        relAtt_ = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(proc_.apvts, id + "release",   relKnob_.slider);
        repaint();
    }

    void paint(juce::Graphics& g) override {
        auto bounds = getLocalBounds().toFloat().reduced(2.0f);
        auto leftPanel = bounds.removeFromLeft(bounds.getWidth() * 0.32f);
        bounds.removeFromLeft(10.0f);
        auto rightPanel = bounds;

        // Left: Velocity & Layer Mapper
        g.setColour(PulseLookAndFeel::kBgPanel);
        g.fillRoundedRectangle(leftPanel, 6.0f);
        g.setColour(PulseLookAndFeel::kBorder);
        g.drawRoundedRectangle(leftPanel, 6.0f, 1.0f);

        auto leftInner = leftPanel.reduced(10.0f);
        g.setColour(PulseLookAndFeel::kTextMain);
        g.setFont(juce::FontOptions(12.0f, juce::Font::bold));
        g.drawText("VELOCITY & LAYER MAPPER", leftInner.removeFromTop(18.0f), juce::Justification::centredLeft);

        auto curveRect = leftInner.removeFromTop(104.0f);
        g.setColour(PulseLookAndFeel::kBgScope);
        g.fillRoundedRectangle(curveRect, 4.0f);
        g.setColour(PulseLookAndFeel::kBorder);
        g.drawRoundedRectangle(curveRect, 4.0f, 1.0f);

        const float curveVal = static_cast<float>(velKnob_.slider.getValue());
        juce::Path curvePath;
        for (int i = 0; i <= 64; ++i) {
            const float x01 = static_cast<float>(i) / 64.0f;
            const float y01 = VelocityMapper::mapVelocity01(x01, curveVal);
            const float px = curveRect.getX() + 4.0f + x01 * (curveRect.getWidth() - 8.0f);
            const float py = curveRect.getBottom() - 4.0f - y01 * (curveRect.getHeight() - 8.0f);
            if (i == 0) curvePath.startNewSubPath(px, py);
            else        curvePath.lineTo(px, py);
        }
        g.setColour(PulseLookAndFeel::kCyanWave);
        g.strokePath(curvePath, juce::PathStrokeType(2.4f));

        const int liveVel = proc_.lastDetectedMidiVel.load(std::memory_order_relaxed);
        if (liveVel > 0) {
            const float lx01 = (liveVel - 1) / 126.0f;
            const float ly01 = VelocityMapper::mapVelocity01(lx01, curveVal);
            const float dx = curveRect.getX() + 4.0f + lx01 * (curveRect.getWidth() - 8.0f);
            const float dy = curveRect.getBottom() - 4.0f - ly01 * (curveRect.getHeight() - 8.0f);
            g.setColour(PulseLookAndFeel::kAmberTrig);
            g.fillEllipse(dx - 5.0f, dy - 5.0f, 10.0f, 10.0f);
        }

        // Right: Velocity Zone Editor
        g.setColour(PulseLookAndFeel::kBgPanel);
        g.fillRoundedRectangle(rightPanel, 6.0f);
        g.setColour(PulseLookAndFeel::kBorder);
        g.drawRoundedRectangle(rightPanel, 6.0f, 1.0f);

        auto inner = rightPanel.reduced(12.0f);
        g.setColour(PulseLookAndFeel::kTextMain);
        g.setFont(juce::FontOptions(12.5f, juce::Font::bold));
        g.drawText("VELOCITY ZONE EDITOR  -  SLOT " + juce::String(activeSlot_ + 1),
                   inner.removeFromTop(24.0f), juce::Justification::centredLeft);

        auto ruler = inner.removeFromTop(22.0f);
        g.setColour(PulseLookAndFeel::kBgScope);
        g.fillRoundedRectangle(ruler, 3.0f);
        g.setColour(PulseLookAndFeel::kTextMute);
        g.setFont(juce::FontOptions(11.0f, juce::Font::bold));
        g.drawText("1",   ruler.reduced(6, 0), juce::Justification::centredLeft);
        g.drawText("64",  ruler,               juce::Justification::centred);
        g.drawText("127", ruler.reduced(6, 0), juce::Justification::centredRight);

        inner.removeFromTop(8.0f);
        laneArea_ = inner;

        const auto& slot = proc_.getSampleEngine().getSlot(activeSlot_);
        const std::array<juce::Colour, 3> laneCols = {
            PulseLookAndFeel::kAmberTrig, PulseLookAndFeel::kCobalt, PulseLookAndFeel::kTealSoft
        };
        const std::array<int, 3> displayOrder = { 2, 1, 0 };
        const float laneH = inner.getHeight() / 3.0f - 6.0f;

        for (int row = 0; row < 3; ++row) {
            const int zIdx = displayOrder[static_cast<size_t>(row)];
            if (zIdx >= static_cast<int>(slot.zones.size())) continue;
            const auto& z = slot.zones[static_cast<size_t>(zIdx)];
            auto laneRect = juce::Rectangle<float>(inner.getX(), inner.getY() + row * (laneH + 6.0f), inner.getWidth(), laneH);

            g.setColour(laneCols[static_cast<size_t>(row)].withAlpha(0.10f));
            g.fillRoundedRectangle(laneRect, 5.0f);
            g.setColour(laneCols[static_cast<size_t>(row)].withAlpha(0.75f));
            g.drawRoundedRectangle(laneRect, 5.0f, 1.2f);

            const float x1 = laneRect.getX() + ((z.minVel - 1) / 126.0f) * laneRect.getWidth();
            const float x2 = laneRect.getX() + ((z.maxVel - 1) / 126.0f) * laneRect.getWidth();
            auto zoneBox = juce::Rectangle<float>(x1, laneRect.getY() + 2.0f, std::max(56.0f, x2 - x1), laneRect.getHeight() - 4.0f);
            g.setColour(laneCols[static_cast<size_t>(row)].withAlpha(0.28f));
            g.fillRoundedRectangle(zoneBox, 4.0f);

            juce::String txt = juce::String(z.label) + " (" + juce::String(z.minVel) + "-" + juce::String(z.maxVel) + ")";
            if (!z.sampleIndices.empty()) {
                txt += "  -  " + juce::String(static_cast<int>(z.sampleIndices.size())) + " WAV(s)";
            }
            g.setColour(PulseLookAndFeel::kTextMain);
            g.setFont(juce::FontOptions(12.0f, juce::Font::bold));
            g.drawText(txt, laneRect.reduced(10.0f, 2.0f), juce::Justification::centredLeft);

            auto dropBox = laneRect.reduced(6.0f).removeFromRight(96.0f);
            dropBoxes_[static_cast<size_t>(row)] = dropBox;
            g.setColour(laneCols[static_cast<size_t>(row)].withAlpha(0.85f));
            g.drawRoundedRectangle(dropBox, 4.0f, 1.0f);
            g.setFont(juce::FontOptions(10.5f, juce::Font::bold));
            g.drawText("+ DROP WAV", dropBox, juce::Justification::centred);
        }

        if (liveVel > 0) {
            const float nx = ruler.getX() + ((liveVel - 1) / 126.0f) * ruler.getWidth();
            g.setColour(PulseLookAndFeel::kAmberTrig);
            g.drawLine(nx, ruler.getY(), nx, inner.getBottom(), 2.0f);
            juce::Path tri;
            tri.addTriangle(nx - 5.0f, ruler.getY(), nx + 5.0f, ruler.getY(), nx, ruler.getY() + 8.0f);
            g.fillPath(tri);
        }
    }

    void resized() override {
        auto bounds = getLocalBounds().reduced(2);
        auto leftPanel = bounds.removeFromLeft(static_cast<int>(bounds.getWidth() * 0.32f)).reduced(10);
        leftPanel.removeFromTop(128);
        auto row1 = leftPanel.removeFromTop(58);
        velKnob_.setBounds(row1.removeFromLeft(row1.getWidth() / 3));
        dynKnob_.setBounds(row1.removeFromLeft(row1.getWidth() / 2));
        xfKnob_.setBounds(row1);

        auto row2 = leftPanel.removeFromTop(58);
        atkKnob_.setBounds(row2.removeFromLeft(row2.getWidth() / 3));
        susKnob_.setBounds(row2.removeFromLeft(row2.getWidth() / 2));
        relKnob_.setBounds(row2);

        bounds.removeFromLeft(10);
        auto topRight = bounds.reduced(12).removeFromTop(24);
        autoSplitBtn_.setBounds(topRight.removeFromRight(176));
    }

    void mouseDown(const juce::MouseEvent& e) override {
        for (int row = 0; row < 3; ++row) {
            if (dropBoxes_[static_cast<size_t>(row)].contains(e.position)) {
                openZoneFilePicker(2 - row);
                return;
            }
        }
        if (!laneArea_.contains(e.position)) return;
        const int row = std::clamp(static_cast<int>((e.position.y - laneArea_.getY()) / (laneArea_.getHeight() / 3.0f)), 0, 2);
        proc_.auditionSlotZone(activeSlot_, 2 - row);
    }

    bool isInterestedInFileDrag(const juce::StringArray&) override { return true; }
    void filesDropped(const juce::StringArray& files, int, int y) override {
        const float relY = static_cast<float>(y) - laneArea_.getY();
        const int row = std::clamp(static_cast<int>(relY / std::max(1.0f, laneArea_.getHeight() / 3.0f)), 0, 2);
        proc_.loadFilesIntoSlotZone(activeSlot_, 2 - row, files);
        repaint();
    }

private:
    void openZoneFilePicker(int zoneIdx) {
        chooser_ = std::make_unique<juce::FileChooser>("Add WAV Samples to Velocity Zone",
                                                       proc_.getBaseLibraryDir(), "*.wav;*.aif;*.aiff;*.flac");
        chooser_->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles
                              | juce::FileBrowserComponent::canSelectMultipleItems,
            [this, zoneIdx](const juce::FileChooser& fc) {
                juce::StringArray paths;
                for (const auto& f : fc.getResults()) paths.add(f.getFullPathName());
                if (!paths.isEmpty()) {
                    proc_.loadFilesIntoSlotZone(activeSlot_, zoneIdx, paths);
                    repaint();
                }
            });
    }

    void timerCallback() override { repaint(); }

    PulseTrigger2AudioProcessor& proc_;
    int activeSlot_ = 0;
    juce::Rectangle<float> laneArea_;
    std::array<juce::Rectangle<float>, 3> dropBoxes_{};
    std::unique_ptr<juce::FileChooser> chooser_;
    juce::TextButton autoSplitBtn_;
    LabeledKnob velKnob_, dynKnob_, xfKnob_, atkKnob_, susKnob_, relKnob_;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> velAtt_, dynAtt_, xfAtt_, atkAtt_, susAtt_, relAtt_;
};

} // namespace pt2
