#include <iostream>
#include <cassert>
#include <cmath>
#include <vector>
#include "DSP/TransientDetector.h"
#include "DSP/TransientGate.h"
#include "DSP/VelocityMapper.h"
#include "DSP/SampleEngine.h"
#include "DSP/MidiCaptureEngine.h"
#include "Formats/SfzParser.h"

int main() {
    constexpr double kSR = 44100.0;

    // 1. Verify exact latency modes (0 / 16 / 96 samples @ 44.1 kHz)
    pt2::TransientDetector det;
    det.prepare(kSR);
    assert(det.getLatencySamples(pt2::LatencyMode::Zero) == 0);
    assert(det.getLatencySamples(pt2::LatencyMode::Micro) == 16);
    assert(det.getLatencySamples(pt2::LatencyMode::PhaseLock) == 96);

    // 2. Verify transient detection + Stereo L/R Bleed Suppression
    pt2::DetectorParams dp;
    dp.latency = pt2::LatencyMode::Micro;
    dp.detail = 20.0f;
    dp.sensitivity = 60.0f;
    dp.retriggerMs = 35.0f;
    dp.suppressPct = 80.0f;
    dp.useStereoLRBleed = true;

    int trueHits = 0;
    int falseBleedHits = 0;
    for (int n = 0; n < 44100; ++n) {
        // Real snare hits at n = 4410 (0.1s) and n = 22050 (0.5s) on Left channel only
        float inL = 0.0f, inR = 0.0f;
        if (n >= 4410 && n < 5400)  inL += 0.9f * std::exp(-static_cast<float>(n - 4410) / 250.0f) * std::sin(0.05f * (n - 4410));
        if (n >= 22050 && n < 23000) inL += 0.75f * std::exp(-static_cast<float>(n - 22050) / 250.0f) * std::sin(0.05f * (n - 22050));

        // Loud kick bleed at n = 13230 (0.3s) appearing on BOTH L (bleed) and R (kick mic)
        if (n >= 13230 && n < 14200) {
            const float kick = 0.7f * std::exp(-static_cast<float>(n - 13230) / 300.0f) * std::sin(0.02f * (n - 13230));
            inL += kick * 0.45f; // bleed into snare mic
            inR += kick * 1.0f;  // direct kick mic
        }

        float dryL = 0.0f, dryR = 0.0f;
        auto ev = det.processSample(inL, inR, 0.0f, dp, dryL, dryR);
        if (ev.fired) {
            if (n >= 13000 && n <= 14500) ++falseBleedHits;
            else ++trueHits;
        }
    }
    assert(trueHits == 2);
    assert(falseBleedHits == 0);

    // 3. Verify Offline Transient Trimming & Auto-Split by Loudness
    pt2::SampleEngine engine;
    engine.prepare(kSR);
    auto& slot0 = engine.getSlot(0);
    const std::array<float, 3> amps = { 0.25f, 0.95f, 0.55f }; // intentionally unsorted
    for (int i = 0; i < 3; ++i) {
        pt2::LoadedSample s;
        s.name = "Snare_" + std::to_string(i) + ".wav";
        s.left.assign(1000, 0.0f);
        s.right.assign(1000, 0.0f);
        // 40 samples of hidden leading silence before transient!
        for (int n = 40; n < 400; ++n) {
            s.left[static_cast<size_t>(n)]  = amps[static_cast<size_t>(i)] * std::exp(-static_cast<float>(n - 40) / 80.0f);
            s.right[static_cast<size_t>(n)] = s.left[static_cast<size_t>(n)];
        }
        s.analyzeOffline();
        assert(s.startOffset == 38); // 40 - 2 samples pre-attack margin
        slot0.pool.push_back(std::move(s));
    }

    std::vector<pt2::VelocityMapper::SampleLoudnessEntry> entries;
    for (int i = 0; i < 3; ++i) entries.push_back({ i, slot0.pool[static_cast<size_t>(i)].rmsLoudness });
    slot0.zones = pt2::VelocityMapper::autoSplitByLoudness(entries);
    // Soft should have sample 0 (0.25), Medium sample 2 (0.55), Hard sample 1 (0.95)
    assert(slot0.zones[0].sampleIndices.size() == 1 && slot0.zones[0].sampleIndices[0] == 0);
    assert(slot0.zones[1].sampleIndices.size() == 1 && slot0.zones[1].sampleIndices[0] == 2);
    assert(slot0.zones[2].sampleIndices.size() == 1 && slot0.zones[2].sampleIndices[0] == 1);

    // 4. Verify Velocity Curve linearity & polarity
    assert(pt2::VelocityMapper::mapMidiVelocity(64, 50.0f) == 64);
    assert(pt2::VelocityMapper::mapMidiVelocity(64, 80.0f) > 80);
    assert(pt2::VelocityMapper::mapMidiVelocity(64, 20.0f) < 48);

    // 5. Verify SFZ parser
    const std::string sfz = "<group>\n<region> lovel=1 hivel=45 sample=soft.wav\n<region> lovel=46 hivel=127 sample=hard.wav\n";
    auto regs = pt2::SfzParser::parse(sfz);
    assert(regs.size() == 2 && regs[0].samplePath == "soft.wav" && regs[1].hivel == 127);

    // 6. Verify MIDI Capture SMF Type 0 export
    pt2::MidiCaptureEngine midiCap;
    midiCap.recordHit(4410, 1, 38, 110);
    midiCap.recordHit(22050, 1, 38, 95);
    auto smf = midiCap.exportStandardMidiFile(kSR, 120.0, 960);
    assert(smf.size() > 28 && smf[0] == 'M' && smf[1] == 'T' && smf[2] == 'h' && smf[3] == 'd');


    // 7. Verify studio -15 dBFS kick track triggers at strong velocity (> 80)
    {
        pt2::TransientDetector kickDet;
        kickDet.prepare(kSR);
        pt2::DetectorParams kdp;
        kdp.detail = 25.0f;
        kdp.sensitivity = 60.0f;
        int hits = 0, maxVel = 0;
        for (int n = 0; n < 22050; ++n) {
            float x = (n >= 2000 && n < 2800) ? 0.18f * std::exp(-static_cast<float>(n - 2000) / 180.0f) * std::sin(0.03f * (n - 2000)) : 0.0f;
            float dL, dR;
            auto ev = kickDet.processSample(x, x, 0.0f, kdp, dL, dR);
            if (ev.fired) { ++hits; maxVel = std::max(maxVel, ev.midiVelocity); }
        }
        assert(hits == 1);
        assert(maxVel >= 80); // -15 dBFS maps to ~87 MIDI velocity (loud & punchy!)
    }

    // 8. Verify Pro-G / Sonnox style TransientGate (Range -18 dB floor + S-curve Attack + Hold)
    {
        pt2::TransientGate gate;
        gate.prepare(kSR);
        pt2::TransientGate::Params gp;
        gp.enabled = true;
        gp.attackMs = 1.2f;
        gp.holdMs = 60.0f;
        gp.releaseMs = 200.0f;
        gp.rangeDb = -18.0f;
        const float closedGain = gate.processGain(gp);
        assert(closedGain > 0.12f && closedGain < 0.135f); // ~ -18 dB floor (0.1258)
        gate.triggerOpen(gp);
        float g = 0.0f;
        for (int n = 0; n < 100; ++n) g = gate.processGain(gp); // after 2.2 ms (> 1.2 ms attack)
        assert(g > 0.99f); // fully open & holding!
    }

    std::cout << "ALL DSP & FORMAT TESTS PASSED (0/16/96 smp latency, bleed suppression, auto-split, trim, SFZ, SMF .mid)\n";
    return 0;
}
