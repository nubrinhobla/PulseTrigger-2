@echo off
chcp 65001 >nul
title Compilador Automatico - PulseTrigger 2 (Windows VST3)

echo ============================================================
echo   PulseTrigger 2 - Compilacao Automatica para Windows x64
echo ============================================================
echo.

where cmake >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERRO] CMake nao encontrado no PATH.
    echo Instale em: https://cmake.org/download/
    echo Marque a opcao "Add CMake to the system PATH" durante a instalacao.
    pause
    exit /b 1
)

where git >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERRO] Git nao encontrado no PATH.
    echo Instale em: https://git-scm.com/download/win
    pause
    exit /b 1
)

echo [1/3] Configurando projeto e baixando JUCE 8 (pode levar 2-4 min na 1a vez)...
cmake -B build -G "Visual Studio 17 2022" -A x64
if %errorlevel% neq 0 (
    echo Tentando configuracao com gerador padrao do sistema...
    cmake -B build
    if %errorlevel% neq 0 (
        echo [ERRO] Falha ao configurar o CMake. Verifique se o Visual Studio 2022 com C++ esta instalado.
        pause
        exit /b 1
    )
)

echo.
echo [2/3] Compilando PulseTrigger 2 (VST3 + Standalone + Testes DSP)...
cmake --build build --config Release --parallel
if %errorlevel% neq 0 (
    echo [ERRO] Falha na compilacao. Veja as mensagens acima.
    pause
    exit /b 1
)

echo.
echo [3/3] Executando testes unitarios do motor DSP...
if exist "build\Release\dsp_verify.exe" (
    "build\Release\dsp_verify.exe"
)

echo.
echo ============================================================
echo   SUCESSO! Plugin compilado em:
echo   build\PulseTrigger2_artefacts\Release\VST3\PulseTrigger 2.vst3
echo.
echo   Copie a pasta "PulseTrigger 2.vst3" para:
echo   C:\Program Files\Common Files\VST3
echo ============================================================
if exist "build\PulseTrigger2_artefacts\Release\VST3" (
    explorer "build\PulseTrigger2_artefacts\Release\VST3"
)
pause
